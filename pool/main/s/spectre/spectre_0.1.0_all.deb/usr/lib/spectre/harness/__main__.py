import argparse
import signal
import sys
import uuid

from .client import FakeClient, OpenRouterClient
from .context import FakeSummarizer, LLMSummarizer
from pathlib import Path

from . import files, memory
from .init import make_private_dir
from . import __version__
from .config import CONFIG_DIR, PACKAGED, load_api_key, load_config
from .log import MIN_SECRET_CHARS, Logger
from .loop import run
from .tools import Registry


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "init":  # `spectre init`: Schluessel und Ordner einrichten
        from .init import init
        sys.exit(init())
    ap = argparse.ArgumentParser(prog="spectre" if PACKAGED else "python3 -m harness",
                                 description="Kleines Coding-Harness. Erste Einrichtung: spectre init")
    ap.add_argument("--version", action="version", version="spectre " + __version__)
    ap.add_argument("task", help="Aufgabe als Text")
    ap.add_argument("--fake", action="store_true", help="Attrappen-Modell statt OpenRouter (kein Schluessel noetig)")
    ap.add_argument("--fake-delay", type=float, default=0.0, help=argparse.SUPPRESS)
    ap.add_argument("--config", help="Pfad zu einer anderen config.json")
    ap.add_argument("--workdir", help="Arbeitsordner (nur darin darf das Modell Dateien lesen und schreiben)")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.workdir:
        cfg["work_dir"] = str(Path(args.workdir).expanduser().resolve())
    try:
        make_private_dir(Path(cfg["work_dir"]))
    except OSError as e:
        sys.exit("Fehler: Arbeitsordner %s nicht nutzbar: %s" % (cfg["work_dir"], e.strerror or e))
    key = load_api_key()  # auch bei --fake geladen, damit er im Protokoll sicher entfernt wird
    session = uuid.uuid4().hex[:12]
    sm = cfg["summarizer"]
    if args.fake:
        client, summarizer = FakeClient(delay=args.fake_delay), FakeSummarizer()
    elif key:
        client = OpenRouterClient(key, cfg["base_url"], cfg["model"], cfg["max_reply_tokens"], session,
                                  cfg["cache_control_models"])
        summarizer = LLMSummarizer(
            OpenRouterClient(key, cfg["base_url"], sm["model"] or cfg["model"], sm["max_reply_tokens"], session + "-sum",
                             cfg["cache_control_models"]), sm["timeout_seconds"])
    else:
        sys.exit("Kein Schluessel: setze OPENROUTER_API_KEY oder fuehre `spectre init` aus. "
                 "Zum Testen: --fake")

    def on_signal(signum, frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, on_signal)
    if key and len(key) < MIN_SECRET_CHARS:
        print("Warnung: Schluessel kuerzer als %d Zeichen, er wird im Protokoll nicht maskiert." % MIN_SECRET_CHARS,
              file=sys.stderr)
    try:
        logger = Logger(cfg["log_dir"], secrets=[key])
    except OSError as e:
        sys.exit("Fehler: Protokollordner %s nicht nutzbar: %s" % (cfg["log_dir"], e.strerror or e))
    registry = Registry(cfg["max_tool_output_chars"])
    deny = [cfg["log_dir"], cfg["memory_dir"], CONFIG_DIR / "config.json", *cfg["deny_paths"]]
    if args.config:
        deny.append(Path(args.config))
    files.register(registry, cfg["work_dir"], deny, logger.log)
    try:
        store = memory.register(registry, cfg["memory_dir"], secrets=[key])
        index = store.index()
        for w in store.warnings:
            logger.log("warning", message=w)
    except (memory.NoteError, OSError) as e:  # kaputter Notizspeicher: sauber abbrechen, memory.db bleibt unveraendert
        logger.log("error", message="Notizspeicher: %s" % e)
        logger.close()
        sys.exit("Fehler: Notizspeicher nicht nutzbar: %s" % e)
    res = run(args.task, cfg, client, registry, logger, memory_index=index, summarizer=summarizer, session=session)
    logger.close()
    print(res.message if res.status == "ok" else "ABBRUCH (%s): %s" % (res.reason, res.message),
          file=sys.stdout if res.status == "ok" else sys.stderr)
    print("[%d Schritte, %.6f USD (Hauptlauf %.6f, Verdichtung %.6f), %.1f s, Protokoll: %s]" % (
        res.steps, res.cost_usd, res.cost_main_usd, res.cost_compaction_usd, res.seconds, logger.path),
          file=sys.stderr)
    sys.exit(0 if res.status == "ok" else 130 if res.reason == "interrupted" else 2)


if __name__ == "__main__":
    main()
