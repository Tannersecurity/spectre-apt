"""Kleines Coding-Harness: Schleife, Werkzeug-Registry, OpenRouter-Client, Limits, Protokoll."""
__version__ = "0.1.0"
