# Spectre Code

Die Oberflaeche zu Spectre. Start: `spectre` (ohne Aufgabe) oder `spectre-code`.

- Eingabe schreiben, Enter: Spectre arbeitet im Hintergrund; die Statuszeile zeigt Kosten und Schritte.
- Aendern, Ueberschreiben und Shell fragen vorher in einem Dialog, neue Dateien nicht. Bei einer Datei zeigt der Dialog den Pfad und eine kurze Diff-Vorschau (hoechstens 40 Zeilen, Schluessel maskiert), bei der Shell den genauen Befehl und den Ordner. Standard ist Nein (Enter, Esc, 60 Sekunden ohne Antwort). Dateien nur unterhalb des Arbeitsordners.
- Datenschutz: `spectre config zdr on` schickt Anfragen nur an Anbieter ohne Datenspeicherung (Standard aus, `spectre config` zeigt den Zustand; manche Modelle gehen dann nicht). Die Statuszeile zeigt `ZDR an` oder `ZDR aus`.
- `/help`, `/clear`, `/exit`, `/update` (schliesst Spectre Code und holt die neue Version; sudo fragt nach dem Passwort).
- Erste Einrichtung (Schluessel): `spectre init`.
- Die benoetigten Bibliotheken (textual und Abhaengigkeiten) liegen im Paket unter `/usr/lib/spectre-code/vendor`.
