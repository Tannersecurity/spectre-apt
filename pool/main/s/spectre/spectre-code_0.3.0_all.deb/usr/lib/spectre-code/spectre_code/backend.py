"""Anschluss der Oberflaeche an den Harness-Kern (harness.api.run_task).

Der Schluessel wird hier nie gelesen: der Kern laedt ihn selbst und maskiert ihn im Protokoll;
Texte, die in die Oberflaeche gehen, werden zusaetzlich von Schluesselmustern gereinigt.
"""

from __future__ import annotations

from dataclasses import dataclass

FREIGABE_SEKUNDEN = 60          # Dialog schliesst sich nach dieser Zeit mit Nein
API_FREIGABE_SEKUNDEN = FREIGABE_SEKUNDEN + 5   # der Kern wartet etwas laenger, dann ebenfalls Nein


@dataclass
class Antwort:
    text: str
    ok: bool = True
    steps: int = 0
    cost_usd: float = 0.0


def _kern():
    from harness import api, loop
    return api, loop


def sauber(text: str) -> str:
    """Schluesselmuster und Tastenzeichen entfernen, bevor etwas angezeigt wird."""
    from harness.log import KEY_PATTERN
    return KEY_PATTERN.sub("[REDACTED]", text)


def sichtbar(text: str) -> str:
    from harness.shell import sichtbar as s
    return s(text)


def antworten(text, verlauf, on_event=None, approve=None) -> Antwort:
    """Fuehrt die Eingabe als Aufgabe im Kern aus. verlauf enthaelt als Letztes die aktuelle Eingabe (wird abgeschnitten)."""
    if verlauf and verlauf[-1] == ("nutzer", text):
        verlauf = verlauf[:-1]
    try:
        api, loop = _kern()
        out = api.run_task(text, verlauf, on_event=on_event, approve=approve,
                           approve_timeout=API_FREIGABE_SEKUNDEN)
    except ImportError as e:
        return Antwort("Fehler: Der Kern ist nicht erreichbar (%s)." % e, ok=False)
    except Exception as e:  # SetupError und alles Unerwartete: kurze Meldung statt Traceback
        name = type(e).__name__
        if name == "SetupError":
            return Antwort(sauber("Fehler: %s" % e), ok=False)
        return Antwort("Unerwarteter Fehler (%s). Details stehen im Protokoll, falls die Aufgabe gestartet war." % name,
                       ok=False)
    if out.ok:
        return Antwort(sauber(out.text), True, out.steps, out.cost_usd)
    grund = loop.ABORT_TEXT.get(out.reason, out.reason)
    zusatz = " Mach die Aufgabe kleiner oder starte sie neu." if out.reason == "cost_limit" else ""
    return Antwort(sauber("Abgebrochen: %s (%s).%s" % (grund, out.text, zusatz)), False, out.steps, out.cost_usd)
