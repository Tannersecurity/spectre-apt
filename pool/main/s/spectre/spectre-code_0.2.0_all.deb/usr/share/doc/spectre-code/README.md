# Spectre Code

Die Oberflaeche zu Spectre. Start: `spectre` (ohne Aufgabe) oder `spectre-code`.

- Eingabe schreiben, Enter: Spectre arbeitet im Hintergrund; die Statuszeile zeigt Kosten und Schritte.
- Werkzeuge, die eine Freigabe verlangen, fragen vorher in einem Dialog. Standard ist Nein (Enter, Esc, 60 Sekunden ohne Antwort). Die Dateiwerkzeuge (`write_file`, `edit_file`) fragen nicht: sie schreiben ohne Rueckfrage, aber nur unterhalb des Arbeitsordners.
- `/help`, `/clear`, `/exit`, `/update` (schliesst Spectre Code und holt die neue Version; sudo fragt nach dem Passwort).
- Erste Einrichtung (Schluessel): `spectre init`.
- Die benoetigten Bibliotheken (textual und Abhaengigkeiten) liegen im Paket unter `/usr/lib/spectre-code/vendor`.
