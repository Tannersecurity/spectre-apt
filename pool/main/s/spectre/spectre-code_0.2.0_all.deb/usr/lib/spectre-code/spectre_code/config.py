"""Anzeige-Konfiguration für den Startbildschirm.

Modell und Ordner kommen aus der Konfiguration des Kerns (harness.config), Netz und Datenschutz
sind feste Texte. Umgebungsvariablen überschreiben die Vorgaben, falls gesetzt:

- SPECTRE_MODELL
- SPECTRE_ORDNER  (sonst das aktuelle Verzeichnis, mit ~ gekürzt)
- SPECTRE_NETZ
- SPECTRE_DATENSCHUTZ
"""

from __future__ import annotations

import os
from pathlib import Path

STANDARD_NETZ = "nur openrouter.ai (Modellaufruf)"
STANDARD_DATENSCHUTZ = "Notizen und Protokolle bleiben lokal, Anfragen gehen an OpenRouter"


def _kern_wert(name: str, standard: str) -> str:
    """Echter Wert aus der Konfiguration des Kerns; ohne Kern der Standard."""
    try:
        from harness.config import load_config
        cfg = load_config()
        return str(cfg[name])
    except Exception:
        return standard


def _kurz(pfad: str) -> str:
    home = str(Path.home())
    return "~" + pfad[len(home):] if pfad == home or pfad.startswith(home + os.sep) else pfad


def _umgebung(name: str, standard: str) -> str:
    wert = os.environ.get(name)
    if wert is None:
        return standard
    wert = wert.strip()
    return wert if wert else standard


def aktuelles_verzeichnis() -> str:
    """Aktuelles Arbeitsverzeichnis, plattformunabhängig, mit ~ falls unter Home."""
    cwd = Path.cwd()
    home = Path.home()
    cwd_s = str(cwd)
    home_s = str(home)
    if cwd_s == home_s:
        return "~"
    trenner = os.sep
    prefix = home_s + trenner
    if cwd_s.startswith(prefix):
        return "~" + trenner + cwd_s[len(prefix) :]
    return cwd_s


def modell() -> str:
    return _umgebung("SPECTRE_MODELL", _kern_wert("model", "unbekannt") + " über OpenRouter")


def ordner() -> str:
    """Der Arbeitsordner des Kerns: nur darin darf das Modell Dateien lesen und schreiben."""
    wert = os.environ.get("SPECTRE_ORDNER")
    if wert is not None and wert.strip():
        return wert.strip()
    return _kurz(_kern_wert("work_dir", aktuelles_verzeichnis()))


def netz() -> str:
    return _umgebung("SPECTRE_NETZ", STANDARD_NETZ)


def datenschutz() -> str:
    return _umgebung("SPECTRE_DATENSCHUTZ", STANDARD_DATENSCHUTZ)
