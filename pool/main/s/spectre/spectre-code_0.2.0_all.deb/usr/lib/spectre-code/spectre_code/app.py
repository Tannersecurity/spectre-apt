"""Spectre Code TUI: Startbildschirm, Chat-Verlauf und Eingabe."""

from __future__ import annotations

import threading

from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, RichLog, Static

from spectre_code import backend
from spectre_code.config import datenschutz, modell, netz, ordner

try:
    from harness import __version__ as VERSION
except ImportError:
    from spectre_code import __version__ as VERSION

HINTERGRUND = "#0c0e18"
CYAN = "#00d4ff"
TEXTFARBE = "#cdd2e6"
LABELFARBE = "#788097"
GEDÄMPFT = "#46506e"
LINIENFARBE = "#46506e"
STATUSFARBE = "#3d4658"
TITEL_START = (154, 107, 255)  # #9a6bff
TITEL_ENDE = (0, 212, 255)  # #00d4ff

# Streifen des Pixel-Geists von oben nach unten.
GEIST_FARBEN = [
    "#9a6bff",
    "#8a63e0",
    "#7a5bd0",
    "#6a52b2",
    "#5a4a94",
    "#3a3470",
    "#22223e",
    "#22223e",
]

# Breite 18, aus █ ▀ ▄; Augenlöcher als Leerraum, cyan-Pupillen, drei Fransen, zwei Punkte.
GEIST = [
    "     ▄▄████▄▄     ",
    "   ▄██████████▄   ",
    "  ████ ●██● ████  ",
    "  ██████████████  ",
    "  ██████████████  ",
    "   ████████████   ",
    "    ██  ████  ██  ",
    "     ·   ██   ·   ",
]

TITEL = "S P E C T R E   C O D E"

HILFETEXT = (
    "Verfügbare Befehle:\n"
    "  /help   zeigt alle Befehle\n"
    "  /clear  leert den Verlauf\n"
    "  /exit   beendet Spectre Code\n"
    "  /update schliesst Spectre Code und holt die neue Version (sudo fragt nach dem Passwort)\n"
    "Pfeiltasten hoch und runter holen alte Eingaben zurück."
)

def status_text(zustand: str = "Bereit", kosten: float | None = None, schritte: int | None = None) -> str:
    k = "--" if kosten is None else f"{kosten:.4f} USD"
    n = "--" if schritte is None else str(schritte)
    return f"/help   /clear   /exit   /update        {zustand} · Kosten: {k} · Schritte: {n}"


STATUS_TEXT = status_text()
FREIGABE_ARGUMENTE_MAX = 800


class FreigabeDialog(ModalScreen[bool]):
    """Fragt vor einem Werkzeug mit Aussenwirkung. Standard ist Nein: Enter, Esc, Zeitablauf und Schliessen heissen Nein."""

    BINDINGS = [
        Binding("j", "ja", "Ja", show=False),
        Binding("y", "ja", "Ja", show=False),
        Binding("n", "nein", "Nein", show=False),
        Binding("escape", "nein", "Nein", show=False),
    ]
    DEFAULT_CSS = f"""
    FreigabeDialog {{ align: center middle; background: {HINTERGRUND} 70%; }}
    #dialog {{ width: 70; height: auto; background: {HINTERGRUND}; border: round {CYAN}; padding: 1 2; }}
    #dialog-titel {{ color: {CYAN}; text-style: bold; }}
    #dialog-knoepfe {{ height: 3; margin-top: 1; }}
    #dialog-knoepfe Button {{ margin-right: 2; }}
    """

    def __init__(self, werkzeug: str, argumente: object, sekunden: int = 60) -> None:
        super().__init__()
        self.werkzeug = werkzeug
        self.argumente = argumente
        self.sekunden = sekunden
        self._fertig = False

    def compose(self) -> ComposeResult:
        from spectre_code import backend
        roh = backend.sauber(str(self.argumente))
        if len(roh) > FREIGABE_ARGUMENTE_MAX:
            roh = roh[:FREIGABE_ARGUMENTE_MAX] + " …"
        with Vertical(id="dialog"):
            yield Label("Freigabe nötig", id="dialog-titel")
            yield Label(Text(f"Werkzeug: {self.werkzeug}"))
            yield Label(Text(f"Argumente: {roh}"))
            yield Label(f"Ohne Antwort gilt nach {self.sekunden} Sekunden Nein.")
            with Horizontal(id="dialog-knoepfe"):
                yield Button("Nein (n)", id="nein", variant="primary")
                yield Button("Ja (j)", id="ja", variant="error")

    def on_mount(self) -> None:
        self.query_one("#nein", Button).focus()
        self.set_timer(self.sekunden, self.action_nein)

    def _beenden(self, antwort: bool) -> None:
        if not self._fertig:
            self._fertig = True
            self.dismiss(antwort)

    def action_ja(self) -> None:
        self._beenden(True)

    def action_nein(self) -> None:
        self._beenden(False)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self._beenden(event.button.id == "ja")


def _lerp(start: tuple[int, int, int], ende: tuple[int, int, int], t: float) -> str:
    t = max(0.0, min(1.0, t))
    rgb = tuple(int(start[i] + (ende[i] - start[i]) * t) for i in range(3))
    return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"


def _titel_verlauf(text: str) -> Text:
    zeile = Text()
    n = max(len(text) - 1, 1)
    for i, zeichen in enumerate(text):
        if zeichen == " ":
            zeile.append(" ")
        else:
            zeile.append(zeichen, style=f"bold {_lerp(TITEL_START, TITEL_ENDE, i / n)}")
    return zeile


def _geist_zeile(roh: str, farbe: str) -> Text:
    zeile = Text()
    for zeichen in roh:
        if zeichen == "●":
            zeile.append(zeichen, style=f"bold {CYAN}")
        elif zeichen == " ":
            zeile.append(" ")
        elif zeichen == "█":
            # Hintergrund gleich Vordergrund: keine Fugen zwischen Blöcken.
            zeile.append(zeichen, style=f"{farbe} on {farbe}")
        else:
            zeile.append(zeichen, style=farbe)
    return zeile


def baue_startbild(
    modell_wert: str | None = None,
    ordner_wert: str | None = None,
    netz_wert: str | None = None,
    datenschutz_wert: str | None = None,
) -> Text:
    """Baut den Startbildschirm (Geist, Titel, Anzeigezeilen)."""
    modell_wert = modell_wert if modell_wert is not None else modell()
    ordner_wert = ordner_wert if ordner_wert is not None else ordner()
    netz_wert = netz_wert if netz_wert is not None else netz()
    datenschutz_wert = (
        datenschutz_wert if datenschutz_wert is not None else datenschutz()
    )

    info: list[Text | None] = [
        None,
        _titel_verlauf(TITEL),
        Text("━" * len(TITEL), style=LINIENFARBE),
        Text(f"v{VERSION}", style=LABELFARBE),
        None,
        Text.assemble(("◆ ", CYAN), ("Modell     ", LABELFARBE), (modell_wert, TEXTFARBE)),
        Text.assemble(("◆ ", CYAN), ("Ordner     ", LABELFARBE), (ordner_wert, TEXTFARBE)),
        Text.assemble(("◆ ", CYAN), ("Netz       ", LABELFARBE), (netz_wert, TEXTFARBE)),
    ]

    rahmen = Text()
    for i, roh in enumerate(GEIST):
        rahmen.append_text(_geist_zeile(roh, GEIST_FARBEN[i]))
        extra = info[i] if i < len(info) else None
        if extra is not None:
            rahmen.append("  ")
            rahmen.append_text(extra)
        rahmen.append("\n")
    rahmen.append("\n")
    rahmen.append("◆ ", style=CYAN)
    rahmen.append("Datenschutz  ", style=LABELFARBE)
    rahmen.append(datenschutz_wert, style=TEXTFARBE)
    return rahmen


class Willkommen(Static):
    """Startbereich mit Pixel-Geist, Titel und Anzeigezeilen."""

    def on_mount(self) -> None:
        self.update(baue_startbild())


class EingabeFeld(Input):
    """Eingabezeile mit Verlauf über die Pfeiltasten hoch und runter."""

    BINDINGS = [
        Binding("up", "verlauf_zurueck", "Ältere Eingabe", show=False),
        Binding("down", "verlauf_vor", "Neuere Eingabe", show=False),
    ]

    def __init__(self, **kwargs: object) -> None:
        super().__init__(**kwargs)
        self._historie: list[str] = []
        self._index: int | None = None
        self._entwurf: str = ""

    def eintrag_speichern(self, text: str) -> None:
        if text and (not self._historie or self._historie[-1] != text):
            self._historie.append(text)
        self._index = None
        self._entwurf = ""

    def action_verlauf_zurueck(self) -> None:
        if not self._historie:
            return
        if self._index is None:
            self._entwurf = self.value
            self._index = len(self._historie) - 1
        elif self._index > 0:
            self._index -= 1
        self.value = self._historie[self._index]
        self.cursor_position = len(self.value)

    def action_verlauf_vor(self) -> None:
        if self._index is None:
            return
        if self._index < len(self._historie) - 1:
            self._index += 1
            self.value = self._historie[self._index]
        else:
            self._index = None
            self.value = self._entwurf
        self.cursor_position = len(self.value)

    def verlauf_position_zuruecksetzen(self) -> None:
        self._index = None
        self._entwurf = ""


class SpectreApp(App[str]):
    """Hauptanwendung von Spectre Code."""

    TITLE = "Spectre Code"
    CSS = f"""
    Screen {{
        background: {HINTERGRUND};
        color: {TEXTFARBE};
        layout: vertical;
    }}

    #willkommen {{
        height: auto;
        padding: 1 2 0 1;
        background: {HINTERGRUND};
    }}

    #verlauf {{
        height: 1fr;
        background: {HINTERGRUND};
        color: {TEXTFARBE};
        padding: 1 2 0 1;
        scrollbar-background: {HINTERGRUND};
        scrollbar-color: #3a3470;
        scrollbar-color-hover: {CYAN};
        overflow-x: hidden;
    }}

    #eingabezeile {{
        height: 1;
        background: {HINTERGRUND};
        padding: 0 2 0 1;
    }}

    #prompt {{
        width: 2;
        height: 1;
        color: {CYAN};
        padding: 0;
        content-align: left middle;
    }}

    #eingabe {{
        width: 1fr;
        height: 1;
        background: {HINTERGRUND};
        color: {TEXTFARBE};
        border: none;
        padding: 0;
    }}

    #eingabe:focus {{
        border: none;
        background: {HINTERGRUND};
        background-tint: {HINTERGRUND} 0%;
    }}

    #eingabe > .input--cursor {{
        background: {CYAN};
        color: {HINTERGRUND};
    }}

    #eingabe > .input--placeholder {{
        color: {GEDÄMPFT};
    }}

    #linie {{
        height: 1;
        background: {HINTERGRUND};
        color: {LINIENFARBE};
        padding: 0 2 0 1;
    }}

    #status {{
        height: 1;
        background: {HINTERGRUND};
        color: {STATUSFARBE};
        padding: 0 2 0 1;
    }}
    """

    BINDINGS = [
        Binding("escape", "eingabe_abbrechen", "Eingabe abbrechen", show=False),
        Binding("ctrl+c", "quit", "Beenden", show=False, priority=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self.protokoll: list[tuple[str, str]] = []
        self.gespraech: list[tuple[str, str]] = []
        self.beschaeftigt = False
        self.sitzung_kosten: float | None = None
        self.sitzung_schritte: int | None = None
        self._aufgabe_kosten = 0.0
        self._aufgabe_schritte = 0

    def compose(self) -> ComposeResult:
        yield Willkommen(id="willkommen")
        yield RichLog(
            id="verlauf",
            wrap=True,
            highlight=False,
            markup=False,
            auto_scroll=True,
            min_width=20,
        )
        with Horizontal(id="eingabezeile"):
            yield Label("❯", id="prompt")
            yield EingabeFeld(
                placeholder="Was soll ich bauen?",
                id="eingabe",
            )
        yield Static("╌" * 60, id="linie")
        yield Static(STATUS_TEXT, id="status")

    def on_mount(self) -> None:
        self.query_one("#eingabe", EingabeFeld).focus()

    def action_eingabe_abbrechen(self) -> None:
        feld = self.query_one("#eingabe", EingabeFeld)
        feld.value = ""
        feld.verlauf_position_zuruecksetzen()

    def _zeile_schreiben(self, markierung: str, mark_stil: str, text: str) -> None:
        log = self.query_one("#verlauf", RichLog)
        inhalt = Text()
        inhalt.append(markierung, style=mark_stil)
        inhalt.append(text, style=TEXTFARBE)
        log.write(inhalt)

    def _befehl_ausfuehren(self, befehl: str) -> bool:
        if befehl == "/help":
            self._zeile_schreiben("● ", "#9a6bff", HILFETEXT)
            self.protokoll.append(("spectre", HILFETEXT))
            return True
        if befehl == "/clear":
            self.query_one("#verlauf", RichLog).clear()
            self.protokoll.clear()
            self.gespraech.clear()
            return True
        if befehl == "/exit":
            self.exit()
            return True
        if befehl == "/update":
            self._zeile_schreiben("● ", "#9a6bff", "Ich schliesse mich und starte das Update im Terminal.")
            self.exit("update")
            return True
        return False

    def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value.strip()
        feld = self.query_one("#eingabe", EingabeFeld)
        if not text:
            return
        if self.beschaeftigt and text.split()[0] not in {"/help", "/exit"}:
            self._zeile_schreiben("● ", "#9a6bff", "Ich arbeite noch an der letzten Aufgabe, einen Moment.")
            return
        feld.eintrag_speichern(text)
        feld.value = ""

        if text.startswith("/"):
            bekannt = text.split()[0]
            if bekannt in {"/help", "/clear", "/exit", "/update"}:
                if bekannt != "/clear":
                    self._zeile_schreiben("❯ ", f"bold {CYAN}", text)
                    self.protokoll.append(("nutzer", text))
                self._befehl_ausfuehren(bekannt)
                return
            self._zeile_schreiben("❯ ", f"bold {CYAN}", text)
            self.protokoll.append(("nutzer", text))
            hinweis = "Unbekannter Befehl. Mit /help siehst du alle Befehle."
            self._zeile_schreiben("● ", "#9a6bff", hinweis)
            self.protokoll.append(("spectre", hinweis))
            return

        self._zeile_schreiben("❯ ", f"bold {CYAN}", text)
        self.protokoll.append(("nutzer", text))
        self.gespraech.append(("nutzer", text))
        self.beschaeftigt = True
        self._aufgabe_schritte = 0
        self._aufgabe_kosten = 0.0
        self._setze_status("Arbeitet …")
        threading.Thread(target=self._arbeit, args=(text, list(self.gespraech)), daemon=True).start()

    # --- Aufgabe laeuft im eigenen Thread (daemon: das Schliessen der App wartet nie auf einen Modellaufruf) ---

    def _arbeit(self, text: str, verlauf: list[tuple[str, str]]) -> None:
        def on_event(e: dict) -> None:
            self.call_from_thread(self._ereignis, e)

        def approve(name: str, args: object) -> bool:
            box = [False]
            fertig = threading.Event()
            self.call_from_thread(self._frage, name, args, box, fertig)
            fertig.wait()
            return box[0]

        antwort = backend.antworten(text, verlauf, on_event, approve)
        try:
            self.call_from_thread(self._fertig, antwort)
        except Exception:
            pass  # App wurde schon geschlossen

    def _frage(self, name: str, args: object, box: list, fertig: threading.Event) -> None:
        def antwort(ok: bool | None) -> None:
            box[0] = bool(ok)
            fertig.set()

        self.push_screen(FreigabeDialog(name, args, backend.FREIGABE_SEKUNDEN), antwort)

    def _setze_status(self, zustand: str) -> None:
        if self.sitzung_kosten is None and not (self._aufgabe_kosten or self._aufgabe_schritte):
            kosten = schritte = None  # noch nichts gelaufen
        else:
            kosten = (self.sitzung_kosten or 0.0) + self._aufgabe_kosten
            schritte = (self.sitzung_schritte or 0) + self._aufgabe_schritte
        self.query_one("#status", Static).update(status_text(zustand, kosten, schritte))

    def _ereignis(self, e: dict) -> None:
        art = e.get("type")
        if art == "model":
            self._aufgabe_kosten = float(e.get("cost_usd") or 0.0)
            self._aufgabe_schritte = int(e.get("step") or self._aufgabe_schritte)
            self._setze_status("Arbeitet …")
        elif art == "tool_start":
            self._setze_status(f"Arbeitet · {e.get('tool')}")
        elif art == "tool_end":
            sek = e.get("seconds")
            dauer = f" ({sek} s)" if sek is not None else ""
            self._zeile_schreiben("  · ", GEDÄMPFT, f"{e.get('tool')}{dauer}")

    def _fertig(self, antwort: backend.Antwort) -> None:
        self.beschaeftigt = False
        if antwort.steps or antwort.cost_usd or self.sitzung_kosten is not None:
            self.sitzung_kosten = (self.sitzung_kosten or 0.0) + antwort.cost_usd
            self.sitzung_schritte = (self.sitzung_schritte or 0) + antwort.steps
        self._aufgabe_kosten, self._aufgabe_schritte = 0.0, 0
        self._zeile_schreiben("● ", "#9a6bff", antwort.text)
        self.protokoll.append(("spectre", antwort.text))
        self.gespraech.append(("spectre", antwort.text))
        self._setze_status("Bereit")
        self.query_one("#eingabe", EingabeFeld).focus()


def main() -> str | None:
    """Gibt "update" zurück, wenn die Nutzerin /update eingegeben hat."""
    return SpectreApp().run()


if __name__ == "__main__":
    main()
