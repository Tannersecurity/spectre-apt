import json
import threading
from dataclasses import dataclass
from typing import Callable


@dataclass
class Tool:
    name: str
    description: str          # Zweck, kurz (kostet bei jedem Aufruf Token)
    parameters: dict          # Eingabe als JSON-Schema
    run: Callable[[dict], str]  # Ausgabe: Text
    max_output_chars: int = 0   # Grenze fuer die Ausgabe; 0 = Standard aus der Konfiguration
    needs_approval: "bool | Callable[[dict], bool]" = False  # laeuft nur mit Freigabe; eine Funktion entscheidet pro Aufruf
    approval_view: Callable[[dict], dict] = None  # was der Mensch in der Frage sieht (statt der rohen Argumente), z. B. Pfad und Diff
    on_timeout: Callable[[], None] = None  # raeumt auf (z. B. Unterprozess beenden), wenn die Zeitgrenze das Werkzeug abbricht


class ToolError(Exception):
    """Fehlerhafter Aufruf (unbekanntes Werkzeug, kaputte Argumente): zaehlt als Formatfehler."""


class ToolTimeout(Exception):
    """Ein Werkzeug hat die verbleibende Zeit ueberschritten."""


class Registry:
    def __init__(self, default_max_output_chars=4000, approve=None):
        self.tools = {}
        self.default_max = default_max_output_chars
        self.approve = approve  # optional: approve(name, args) -> bool, fuer Werkzeuge mit needs_approval

    def register(self, tool):
        self.tools[tool.name] = tool

    def schemas(self):
        """Feste Reihenfolge, damit der Anfang der Anfrage stabil bleibt (guenstiger durch Caching)."""
        return [
            {"type": "function", "function": {"name": t.name, "description": t.description, "parameters": t.parameters}}
            for t in sorted(self.tools.values(), key=lambda t: t.name)
        ]

    def call(self, name, raw_args, timeout=None):
        tool = self.tools.get(name)
        if tool is None:
            raise ToolError("Unbekanntes Werkzeug: %s. Verfuegbar: %s" % (name, ", ".join(sorted(self.tools)) or "keine"))
        try:
            args = json.loads(raw_args) if raw_args else {}
            if not isinstance(args, dict):
                raise ValueError("Argumente muessen ein JSON-Objekt sein")
        except ValueError as e:
            raise ToolError("Ungueltige Argumente fuer %s: %s" % (name, e))
        if self._needs_approval(tool, args) and not (self.approve and self.approve(name, self._view(tool, args)) is True):
            return "Nicht ausgefuehrt: %s braucht eine Freigabe." % name
        out = self._run(tool, args, timeout)
        limit = tool.max_output_chars or self.default_max
        if len(out) > limit:
            out = out[:limit] + "\n[... gekuerzt, %d Zeichen mehr]" % (len(out) - limit)
        return out

    @staticmethod
    def _needs_approval(tool, args):
        if not callable(tool.needs_approval):
            return bool(tool.needs_approval)
        try:
            return bool(tool.needs_approval(args))
        except Exception:  # im Zweifel fragen
            return True

    @staticmethod
    def _view(tool, args):
        if tool.approval_view is None:
            return args
        try:
            view = tool.approval_view(args)
        except Exception:
            return args
        return args if view is None else view

    @staticmethod
    def _run(tool, args, timeout):
        """Laeuft in einem Hilfsthread, damit ein haengendes Werkzeug die Zeitgrenze nicht aushebelt.
        Der Thread ist ein Daemon und wird beim Programmende verworfen; Werkzeuge mit Unterprozessen
        muessen dort selbst ein Timeout setzen und aufraeumen."""
        box = {}

        def target():
            try:
                box["out"] = str(tool.run(args))
            except ToolError as e:  # falsche Argumente: zaehlt als Formatfehler
                box["err"] = e
            except Exception as e:  # Fehler im Werkzeug selbst gehen als Text zurueck ans Modell
                box["out"] = "Fehler im Werkzeug: %s" % e

        t = threading.Thread(target=target, daemon=True)
        t.start()
        t.join(timeout)
        if t.is_alive():
            if tool.on_timeout:
                try:
                    tool.on_timeout()
                except Exception:
                    pass
            raise ToolTimeout("Werkzeug %s laeuft noch nach %.1f s" % (tool.name, timeout))
        if "err" in box:
            raise box["err"]
        return box["out"]
