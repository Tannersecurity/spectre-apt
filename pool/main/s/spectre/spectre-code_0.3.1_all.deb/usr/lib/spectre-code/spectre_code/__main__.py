"""Start mit python -m spectre_code."""

from spectre_code.app import main

if __name__ == "__main__":
    main()
