"""Spectre Code: eigenständiges Terminal-Chat-Programm."""

__version__ = "0.3.1"
