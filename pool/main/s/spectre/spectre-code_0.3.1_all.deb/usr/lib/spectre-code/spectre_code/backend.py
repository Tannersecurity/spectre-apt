"""Anschluss der Oberflaeche an den Harness-Kern (harness.api.run_task).

Der Schluessel wird hier nie gelesen: der Kern laedt ihn selbst und maskiert ihn im Protokoll;
Texte, die in die Oberflaeche gehen, werden zusaetzlich von Schluesselmustern gereinigt.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

FREIGABE_SEKUNDEN = 60          # Dialog schliesst sich nach dieser Zeit mit Nein
API_FREIGABE_SEKUNDEN = FREIGABE_SEKUNDEN + 5   # der Kern wartet etwas laenger, dann ebenfalls Nein


@dataclass
class Antwort:
    text: str
    ok: bool = True
    steps: int = 0
    cost_usd: float = 0.0


def _kern():
    from harness import api, loop
    return api, loop


_SCHLUESSELANFANG = re.compile(r"(?<![A-Za-z0-9])sk-")
_MAX_ZERLEGT = 80  # laenger als ein Schluessel (rund 73 Zeichen): keine weiteren Teile mehr anhaengen


def _zerlegte_schluessel(text: str) -> str:
    """Maskiert auch Schluessel, die ueber Zeilenumbruch, Tab oder nach einem Bindestrich/Unterstrich getrennt sind.
    Mitten im Wort mit Leerzeichen getrennte Schluessel erkennt das nicht (das Modell bekommt den Schluessel nie)."""
    out, i = [], 0
    while True:
        m = _SCHLUESSELANFANG.search(text, i)
        if not m:
            out.append(text[i:])
            return "".join(out)
        out.append(text[i:m.start()])
        k = m.end()
        while True:
            while k < len(text) and not text[k].isspace():
                k += 1
            l = k
            while l < len(text) and text[l].isspace():
                l += 1
            trenner = text[k:l]
            weiter = (l > k and l < len(text) and (text[l].isalnum() or text[l] in "_-")
                      and (text[k - 1] in "-_" or "\n" in trenner or "\t" in trenner)
                      and k - m.start() < _MAX_ZERLEGT)
            if not weiter:
                break
            k = l
        out.append("[REDACTED]" if k - m.start() >= 7 else text[m.start():k])
        i = k


def sauber(text: str) -> str:
    """Schluesselmuster entfernen (zuerst zerlegte Schluessel, dann KEY_PATTERN), bevor etwas angezeigt wird.
    Die Reihenfolge steckt hier in einer Funktion, damit keine Stelle sie falsch herum anwendet."""
    from harness.log import KEY_PATTERN
    return KEY_PATTERN.sub("[REDACTED]", _zerlegte_schluessel(text))


def anzeigetext(text: str) -> str:
    """Fuer die Markdown-Anzeige: Schluessel maskieren (auch zerlegte), dann Steuerzeichen (ausser Zeilenumbruch und Tab) entfernen."""
    text = sauber(text)
    return "".join(c for c in text if c in "\n\t" or c.isprintable())


def sichtbar(text: str) -> str:
    from harness.shell import sichtbar as s
    return s(text)


def antworten(text, verlauf, on_event=None, approve=None) -> Antwort:
    """Fuehrt die Eingabe als Aufgabe im Kern aus. verlauf enthaelt als Letztes die aktuelle Eingabe (wird abgeschnitten)."""
    if verlauf and verlauf[-1] == ("nutzer", text):
        verlauf = verlauf[:-1]
    try:
        api, loop = _kern()
        out = api.run_task(text, verlauf, on_event=on_event, approve=approve,
                           approve_timeout=API_FREIGABE_SEKUNDEN)
    except ImportError as e:
        return Antwort("Fehler: Der Kern ist nicht erreichbar (%s)." % e, ok=False)
    except Exception as e:  # SetupError und alles Unerwartete: kurze Meldung statt Traceback
        name = type(e).__name__
        if name == "SetupError":
            return Antwort(sauber("Fehler: %s" % e), ok=False)
        return Antwort("Unerwarteter Fehler (%s). Details stehen im Protokoll, falls die Aufgabe gestartet war." % name,
                       ok=False)
    if out.ok:
        return Antwort(sauber(out.text), True, out.steps, out.cost_usd)
    grund = loop.ABORT_TEXT.get(out.reason, out.reason)
    zusatz = " Mach die Aufgabe kleiner oder starte sie neu." if out.reason == "cost_limit" else ""
    return Antwort(sauber("Abgebrochen: %s (%s).%s" % (grund, out.text, zusatz)), False, out.steps, out.cost_usd)
