# Spectre Code

Die Oberflaeche zu Spectre. Start: `spectre` (ohne Aufgabe) oder `spectre-code`.

- Eingabe schreiben, Enter: Spectre arbeitet im Hintergrund; die Statuszeile zeigt Kosten und Schritte.
- Aendern, Ueberschreiben und Shell fragen vorher in einem Dialog, neue Dateien nicht. Bei einer Datei zeigt der Dialog den Pfad und eine kurze Diff-Vorschau (hoechstens 40 Zeilen, Schluessel maskiert), bei der Shell den genauen Befehl und den Ordner. Standard ist Nein (Enter, Esc, 60 Sekunden ohne Antwort). Hat sich eine Datei zwischen deiner Antwort und dem Schreiben veraendert, wird nichts geschrieben.
- Die Dateiwerkzeuge (lesen, schreiben, aendern, suchen) arbeiten nur unterhalb des Arbeitsordners. **Die Shell gehoert nicht dazu** (siehe «Grenzen der Shell» unten).
- Antworten erscheinen als Markdown (fett, Listen, Codebloecke, Links). Links werden nie geoeffnet; die Adresse hinter einem Linktext ist nicht sichtbar. Schluessel werden vor dem Anzeigen maskiert (auch ein Schluessel, der ueber Zeilenumbruch, Tab oder nach einem Bindestrich getrennt ist; mitten im Wort mit Leerzeichen getrennte Schluessel erkennt die Anzeige nicht).
- Datenschutz: `spectre config zdr on` schickt Anfragen nur an Anbieter ohne Datenspeicherung (Standard aus, `spectre config` zeigt den Zustand; manche Modelle gehen dann nicht). Die Statuszeile zeigt `ZDR an` oder `ZDR aus`.
- `/help`, `/clear`, `/exit`, `/update` (schliesst Spectre Code und holt die neue Version; sudo fragt nach dem Passwort).
- Erste Einrichtung (Schluessel): `spectre init`.
- Die benoetigten Bibliotheken (textual und Abhaengigkeiten) liegen im Paket unter `/usr/lib/spectre-code/vendor`.

## Grenzen der Shell (ehrlich)

Die Shell laeuft nur nach deiner Freigabe, bei jedem Aufruf. Lies den Befehl im Dialog genau, bevor du Ja sagst: **Die Freigabe ist die eigentliche Grenze, die Shell ist nicht abgeschottet.**

- Ein freigegebener Befehl kann Dateien ausserhalb des Arbeitsordners lesen und aendern und ins Netz gehen, alles, was dein Benutzer darf. Es gibt keine Dateisandbox fuer die Shell; die Pfadsperre gilt nur fuer die Dateiwerkzeuge.
- Die Sperre fuer `sudo`, `su`, `doas` und `pkexec` ist nur eine Huerde, keine Isolation. Andere Schreibweisen (zum Beispiel `SUDO` in Grossbuchstaben, das auf Linux aber kein Programm ist) und Umwege ueber andere Programme oder Skripte erkennt sie nicht.
- Nach Zeitablauf wird die Prozessgruppe beendet. Ein Kindprozess, der sich mit `setsid` loest, entkommt dem.
- Die Pruefung vor dem Schreiben (Datei seit deiner Antwort veraendert?) verkleinert das Zeitfenster, schliesst es aber nicht ganz: zwischen Vergleich und Schreiben bleibt ein winziges Fenster, und bei Dateien ueber 64 KB deckt der Hash nur den Anfang (der Rest wird ueber Groesse und Aenderungszeit erkannt).
