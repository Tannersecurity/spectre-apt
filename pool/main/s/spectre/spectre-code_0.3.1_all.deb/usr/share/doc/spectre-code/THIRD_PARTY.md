# Mitgelieferte Bibliotheken (Paket spectre-code)

Unveraenderte Wheels von PyPI, entpackt unter `/usr/lib/spectre-code/vendor`. Die SHA256-Werte wurden beim Bau mit den von PyPI
veroeffentlichten Werten (pypi.org JSON-Schnittstelle) verglichen und stimmen ueberein. Der Bau prueft sie zusaetzlich gegen `wheels/SHA256SUMS`.
Die Lizenztexte liegen im jeweiligen `*.dist-info`-Ordner im vendor-Ordner.

| Paket | Version | Herkunft | SHA256 des Wheels | Lizenz |
|---|---|---|---|---|
| linkify-it-py | 2.2.0 | https://pypi.org/project/linkify-it-py/2.2.0/ | `3adc40eb5af300b2605fcfdb968c24e1d780a90f1f2221af7c15e5111e94d443` | MIT |
| markdown-it-py | 4.3.0 | https://pypi.org/project/markdown-it-py/4.3.0/ | `7aa1511a46c39138de78d9eba92ce47e63124d8003fc98b3a351909e04239efa` | MIT License |
| mdit-py-plugins | 0.7.0 | https://pypi.org/project/mdit-py-plugins/0.7.0/ | `7f8e30403f3dd8bfe3afcdcbc6e61066d3f2e714167507b9c26eb385ec399353` | MIT License |
| mdurl | 0.1.2 | https://pypi.org/project/mdurl/0.1.2/ | `84008a41e51615a49fc9966191ff91509e3c40b939176e643fd50a5c2196b8f8` | MIT License |
| platformdirs | 4.12.4 | https://pypi.org/project/platformdirs/4.12.4/ | `78bfb9db2a8471ed7eebe3c3c932da413911042994e699b384fbb4493fa872d7` | MIT |
| pygments | 2.21.0 | https://pypi.org/project/pygments/2.21.0/ | `2363c69b61c4a97c838da3b130dcd6468f4848992b21a82f2a63ec34377137d9` | BSD-2-Clause |
| rich | 15.0.0 | https://pypi.org/project/rich/15.0.0/ | `33bd4ef74232fb73fe9279a257718407f169c09b78a87ad3d296f548e27de0bb` | MIT |
| textual | 8.2.8 | https://pypi.org/project/textual/8.2.8/ | `267375fd402dc8d981457212efa71f0e3365fd17bba144ba9bb3ed7563cb374a` | MIT |
| typing-extensions | 4.16.0 | https://pypi.org/project/typing-extensions/4.16.0/ | `481caa481374e813c1b176ada14e97f1f67a4539ce9cfeb3f350d78d6370c2e8` | PSF-2.0 |

Spectre selbst: Alle Rechte vorbehalten (siehe `copyright`).
