# Spectre Code

Die Oberflaeche zu Spectre. Start: `spectre` (ohne Aufgabe) oder `spectre-code`.

- Eingabe schreiben, Enter: Spectre arbeitet im Hintergrund; die Statuszeile zeigt Kosten und Schritte.
- Aendern, Ueberschreiben und Shell fragen vorher in einem Dialog, neue Dateien nicht. Bei einer Datei zeigt der Dialog den Pfad und eine kurze Diff-Vorschau (hoechstens 40 Zeilen, Schluessel maskiert), bei der Shell den genauen Befehl und den Ordner. Standard ist Nein (Enter, Esc, 60 Sekunden ohne Antwort). Hat sich eine Datei zwischen deiner Antwort und dem Schreiben veraendert, wird nichts geschrieben.
- Der Dialog bricht Befehl, Ordner, Pfad und Vorschau um und schneidet nichts ab, auch auf dem Handy. Steuerzeichen im Befehl erscheinen hervorgehoben als `\n`, `\t`, `\x1b` usw. (nach `\n` beginnt zusaetzlich eine neue Zeile). Passt der Inhalt nicht auf den Bildschirm, ist **Ja erst moeglich, wenn du bis ans Ende gescrollt hast** (Pfeil runter, Bild runter oder Mausrad); vorher tun Taste `j` und Klick auf Ja nichts.
- Schmale Fenster (unter 70 Spalten, z. B. Handy): statt Geist und Infoblock eine Kopfzeile «Spectre Code vX · Modell»; der Kopf scrollt mit dem Verlauf mit, `/clear` laesst ihn stehen. Codebloecke brechen um, die Statuszeile wird kuerzer (ZDR an/aus steht vorne).
- Die Dateiwerkzeuge (lesen, schreiben, aendern, suchen) arbeiten nur unterhalb des Arbeitsordners. **Die Shell gehoert nicht dazu** (siehe «Grenzen der Shell» unten).
- Antworten erscheinen als Markdown (fett, Listen, Codebloecke, Links). Links werden nie geoeffnet; die Adresse hinter einem Linktext ist nicht sichtbar. Schluessel werden vor dem Anzeigen maskiert, ebenso im Protokoll, in Shell-Ausgaben, grep-Treffern und Diff-Vorschauen: `sk-` in jeder Gross-/Kleinschreibung (`SK-`, `Sk-`), auch wenn der Schluessel ueber Zeilenumbruch, Tab oder nach einem Bindestrich getrennt ist (dabei kann ein Wort danach mitmaskiert werden). Mitten im Wort mit Leerzeichen getrennte Schluessel werden nicht erkannt.
- Weitere ehrliche Grenzen:
  - grep sieht pro Treffer nur drei Vorzeilen (je hoechstens 200 Zeichen); ein Schluessel, der ueber mehr als drei Zeilen verteilt ist, kann im Treffer teilweise sichtbar bleiben.
  - `read_file` maskiert nicht: das Modell bekommt den Dateiinhalt im Klartext (der echte Schluessel liegt nie im Arbeitsordner und nie in der Shell-Umgebung). `run_task().text` bleibt die rohe Modellantwort; Oberflaeche und Kommandozeile maskieren sie vor der Anzeige.
  - Im Dialog-Fall «andere Argumente» wird ab 800 Zeichen gekuerzt, sichtbar mit «… [N Zeichen mehr]».
  - In sehr kleinen Fenstern (unter etwa 25×8) liegen die Knoepfe des Freigabe-Dialogs unter dem Bildrand; die Tasten `n` und (nach dem Scrollen) `j` gehen weiter, Standard bleibt Nein. Ab etwa 40×15 ist alles im Bild.
- Datenschutz: `spectre config zdr on` schickt Anfragen nur an Anbieter ohne Datenspeicherung (Standard aus, `spectre config` zeigt den Zustand; manche Modelle gehen dann nicht). Die Statuszeile zeigt `ZDR an` oder `ZDR aus`.
- `/help`, `/clear`, `/exit`, `/update` (schliesst Spectre Code und holt die neue Version; sudo fragt nach dem Passwort).
- Erste Einrichtung (Schluessel): `spectre init`.
- Die benoetigten Bibliotheken (textual und Abhaengigkeiten) liegen im Paket unter `/usr/lib/spectre-code/vendor`.

## Grenzen der Shell (ehrlich)

Die Shell laeuft nur nach deiner Freigabe, bei jedem Aufruf. Lies den Befehl im Dialog genau, bevor du Ja sagst: **Die Freigabe ist die eigentliche Grenze, die Shell ist nicht abgeschottet.**

- Ein freigegebener Befehl kann Dateien ausserhalb des Arbeitsordners lesen und aendern und ins Netz gehen, alles, was dein Benutzer darf. Es gibt keine Dateisandbox fuer die Shell; die Pfadsperre gilt nur fuer die Dateiwerkzeuge.
- Die Sperre fuer `sudo`, `su`, `doas` und `pkexec` ist nur eine Huerde, keine Isolation. Andere Schreibweisen (zum Beispiel `SUDO` in Grossbuchstaben, das auf Linux aber kein Programm ist) und Umwege ueber andere Programme oder Skripte erkennt sie nicht.
- Nach Zeitablauf wird die Prozessgruppe beendet. Ein Kindprozess, der sich mit `setsid` loest, entkommt dem.
- Die Pruefung vor dem Schreiben (Datei seit deiner Antwort veraendert?) verkleinert das Zeitfenster, schliesst es aber nicht ganz: zwischen Vergleich und Schreiben bleibt ein winziges Fenster, und bei Dateien ueber 64 KB deckt der Hash nur den Anfang (der Rest wird ueber Groesse und Aenderungszeit erkannt).
