# Spectre

Kleines Agenten-Harness. Erste Einrichtung: `spectre init` (fragt den OpenRouter-Schluessel mit verdecktem Eingabefeld).
Danach: `spectre "Aufgabe"`, optional `--workdir ORDNER`. `spectre --fake "Aufgabe"` testet ohne Schluessel und ohne Netz.

- Konfiguration: `~/.config/spectre/config.json`, Schluessel: `~/.config/spectre/.env` (nur du kannst ihn lesen)
- Daten und Protokolle: `~/.local/share/spectre/{memory,logs}`
- Arbeitsordner: `~/spectre-work`. Nur hier arbeiten die Dateiwerkzeuge des Modells. Die Shell (nur nach deiner Freigabe) ist nicht darauf begrenzt, siehe die README von `spectre-code`.

Das Paket startet keine Dienste, oeffnet keine Ports und aktualisiert sich nicht selbst.
Deinstallieren: `sudo apt remove spectre`. Deine Daten bleiben, bis du die Ordner oben selbst loeschst.
