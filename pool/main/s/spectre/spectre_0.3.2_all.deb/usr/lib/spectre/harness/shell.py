"""Werkzeug shell: ein Befehl im Arbeitsordner, nur nach Freigabe durch den Menschen, bei jedem einzelnen Aufruf.

Ehrlich gesagt, was das schuetzt und was nicht:
- Die eigentliche Grenze ist die Bestaetigung: Der Mensch sieht den genauen Befehl und den Ordner, Standard ist Nein.
- Die Sperre fuer sudo/su/doas/pkexec ist nur eine zusaetzliche Huerde, keine Abschottung: Ein Befehl kann Programme
  und Dateien ausserhalb des Arbeitsordners lesen, ins Netz gehen und alles tun, was der Benutzer darf.
  Die Pfadsperre der Dateiwerkzeuge gilt fuer die Shell NICHT.
- Was die Shell wirklich begrenzt: leere Umgebung (nur PATH, LANG, HOME = Arbeitsordner, keine Schluessel), leeres stdin,
  Zeitgrenze (30 s, hoechstens 120 s) mit Beenden der ganzen Prozessgruppe, Ausgabe maskiert und auf 4000 Zeichen gekuerzt.
  Ein Kindprozess, der sich mit setsid() aus der Prozessgruppe loest, wird dabei nicht erwischt.
"""
import atexit
import os
import re
import signal
import subprocess
import threading
import time

from .log import scrub_text
from .tools import Tool, ToolError

DEFAULT_SECONDS = 30
MAX_SECONDS = 120
MAX_COMMAND_CHARS = 1000
OUTPUT_CHARS = 4000
READ_CAP = 256 * 1024     # mehr Ausgabe wird gelesen, aber verworfen (Pipe darf nie volllaufen)
BLOCKED = re.compile(r"(?<![\w.-])(sudo|su|doas|pkexec)(?![\w.-])")

_running = set()
_lock = threading.Lock()


def _kill(pid):
    try:
        os.killpg(pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


def kill_all():
    """Beendet alle noch laufenden Befehle (bei Zeitgrenze des Kerns und beim Programmende)."""
    with _lock:
        pids = list(_running)
    for pid in pids:
        _kill(pid)


atexit.register(kill_all)


def sichtbar(command):
    """Befehl so, dass nichts Verstecktes bleibt: Steuerzeichen (Zeilenumbruch, Escape, ...) werden als \\n, \\x1b ... gezeigt."""
    return "".join(c if c.isprintable() else {"\n": "\\n", "\t": "\\t", "\r": "\\r"}.get(c, "\\x%02x" % ord(c) if ord(c) < 256 else "\\u%04x" % ord(c))
                   for c in command)


def register(registry, work_dir, log, secrets=()):
    work_dir = os.path.realpath(work_dir)

    def run(args):
        command = args.get("command")
        if not isinstance(command, str) or not command.strip():
            raise ToolError("command fehlt oder ist kein Text")
        if len(command) > MAX_COMMAND_CHARS:
            raise ToolError("command laenger als %d Zeichen" % MAX_COMMAND_CHARS)
        limit = args.get("timeout_seconds", DEFAULT_SECONDS)
        if isinstance(limit, bool) or not isinstance(limit, (int, float)) or limit <= 0:
            raise ToolError("timeout_seconds muss eine positive Zahl sein")
        limit = min(limit, MAX_SECONDS)
        if BLOCKED.search(command):
            log("blocked", tool="shell", reason="sudo/su gesperrt", command=command[:300])
            return "Gesperrt: sudo, su, doas und pkexec sind nicht erlaubt."
        os.makedirs(work_dir, mode=0o700, exist_ok=True)
        env = {"PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"), "LANG": os.environ.get("LANG", "C.UTF-8"),
               "HOME": work_dir}
        start = time.monotonic()
        p = subprocess.Popen(["/bin/sh", "-c", command], cwd=work_dir, env=env, stdin=subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True, close_fds=True)
        with _lock:
            _running.add(p.pid)
        chunks, size = [], [0]

        def reader():
            while True:
                try:
                    data = os.read(p.stdout.fileno(), 65536)
                except (OSError, ValueError):
                    return
                if not data:
                    return
                if size[0] < READ_CAP:
                    chunks.append(data[:READ_CAP - size[0]])
                    size[0] += len(data)

        t = threading.Thread(target=reader, daemon=True)
        t.start()
        timed_out = False
        try:
            p.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            timed_out = True
        finally:
            _kill(p.pid)  # auch nach normalem Ende: uebrig gebliebene Kindprozesse der Gruppe beenden
            p.wait()
            t.join(2)
            p.stdout.close()
            with _lock:
                _running.discard(p.pid)
        seconds = round(time.monotonic() - start, 2)
        log("shell", command=command, exit_code=p.returncode, seconds=seconds, timed_out=timed_out,
            cwd=work_dir)
        text = scrub_text(b"".join(chunks).decode("utf-8", "replace"), secrets)  # erst maskieren, dann kuerzen
        cut = len(text) - OUTPUT_CHARS
        text = text[:OUTPUT_CHARS] + ("\n[... gekuerzt, %d Zeichen mehr]" % cut if cut > 0 else "")
        head = ("ABGEBROCHEN nach %s s (Zeitgrenze), Befehl beendet. " % limit if timed_out
                else "Exit-Code %s, %s s." % (p.returncode, seconds))
        return head + ("\n" + text if text.strip() else " (keine Ausgabe)")

    registry.register(Tool(
        "shell",
        "Run ONE shell command in work/ (sh -c). The user is asked before every command and may say no. "
        "No stdin, no sudo, default 30 s (max 120 s), output cut at 4000 chars. Prefer read_file/grep/glob for reading.",
        {"type": "object", "properties": {"command": {"type": "string"}, "timeout_seconds": {"type": "integer"}},
         "required": ["command"]},
        run, max_output_chars=OUTPUT_CHARS + 600, needs_approval=True, on_timeout=kill_all))
