"""`/update` in der Oberflaeche: nach dem Schliessen holt dieses Modul die neue Version aus dem Spectre-Archiv.
Nur zwei Paketnamen, nur die Archivquelle von Spectre (andere Quellen bleiben unberuehrt), kein Hintergrundprozess."""
import os
import subprocess
from pathlib import Path

APT_QUELLE = Path("/etc/apt/sources.list.d/spectre.list")
PAKETE = ("spectre", "spectre-code")


def befehle(root=None):
    sudo = [] if (os.geteuid() == 0 if root is None else root) else ["sudo"]
    nur_spectre = ["-o", "Dir::Etc::sourcelist=sources.list.d/spectre.list", "-o", "Dir::Etc::sourceparts=-"]
    return [
        sudo + ["apt-get", "update", *nur_spectre, "-o", "APT::Get::List-Cleanup=0"],
        sudo + ["apt-get", "install", *nur_spectre, "--only-upgrade", "-y", "--no-install-recommends", *PAKETE],
    ]


def version(paket):
    r = subprocess.run(["dpkg-query", "-W", "-f=${Version}", paket], capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else ""


def run_update(call=subprocess.call, get_version=version, quelle=APT_QUELLE, out=print, root=None):
    """Gibt den Exitcode zurueck (0 = erledigt oder schon aktuell)."""
    if not quelle.exists():
        out("Das Spectre-Archiv ist nicht eingerichtet (%s fehlt). Siehe INSTALL.md." % quelle)
        return 1
    alt = get_version("spectre")
    out("Update: suche neue Version im Spectre-Archiv (aktuell %s). sudo fragt nach deinem Passwort." % (alt or "unbekannt"))
    for cmd in befehle(root):
        try:
            rc = call(cmd)
        except OSError as e:
            out("Fehler: %s konnte nicht gestartet werden: %s" % (cmd[0], e.strerror or e))
            return 1
        except KeyboardInterrupt:
            out("Update abgebrochen (Strg+C). Es wurde nichts weiter geaendert.")
            return 1
        if rc != 0:
            out("Update abgebrochen (%s endete mit Code %s). Es wurde nichts weiter geaendert." % (" ".join(cmd[:2]), rc))
            return 1
    neu = get_version("spectre")
    out("Schon aktuell: %s." % neu if neu == alt else "Aktualisiert: %s -> %s. Starte `spectre` neu." % (alt, neu))
    return 0
