import json
import os
import re
import time
import uuid
from pathlib import Path

# Jedes "sk-" in beliebiger Gross-/Kleinschreibung (sk-, SK-, Sk-, sK-), nicht mitten in einem Wort wie "task-" oder
# "disk-", plus mindestens 4 Nicht-Leerzeichen.
KEY_PATTERN = re.compile(r"(?<![A-Za-z0-9])[sS][kK]-\S{4,}")
SCHLUESSELANFANG = re.compile(r"(?<![A-Za-z0-9])[sS][kK]-")
MAX_ZERLEGT = 80  # laenger als ein Schluessel (rund 73 Zeichen): keine weiteren Teile mehr anhaengen
MAX_FIELD_CHARS = 2000
MIN_SECRET_CHARS = 8  # kuerzere Laufzeit-Schluessel wuerden jedes Vorkommen im Text ersetzen


def schluessel_bereiche(text):
    """(Anfang, Ende) jedes Schluessels ab "sk-", auch wenn er ueber Zeilenumbruch, Tab oder nach einem
    Bindestrich/Unterstrich getrennt ist. Mitten im Wort mit Leerzeichen getrennte Schluessel erkennt das nicht."""
    bereiche, i = [], 0
    while True:
        m = SCHLUESSELANFANG.search(text, i)
        if not m:
            return bereiche
        k = m.end()
        while True:
            while k < len(text) and not text[k].isspace():
                k += 1
            l = k
            while l < len(text) and text[l].isspace():
                l += 1
            trenner = text[k:l]
            weiter = (l > k and l < len(text) and (text[l].isalnum() or text[l] in "_-")
                      and (text[k - 1] in "-_" or "\n" in trenner or "\t" in trenner)
                      and k - m.start() < MAX_ZERLEGT)
            if not weiter:
                break
            k = l
        if k - m.start() >= 7:
            bereiche.append((m.start(), k))
        i = k


def zerlegte_schluessel(text):
    """Ersetzt jeden Bereich aus schluessel_bereiche durch [REDACTED]."""
    out, i = [], 0
    for a, b in schluessel_bereiche(text):
        out.append(text[i:a] + "[REDACTED]")
        i = b
    return "".join(out) + text[i:]


def scrub_text(text, secrets=()):
    """Bekannte Schluessel und Schluesselmuster durch [REDACTED] ersetzen (immer vor jedem Kuerzen).
    Reihenfolge: Laufzeit-Schluessel, dann zerlegte Schluessel, dann KEY_PATTERN. Alle Pfade (Log, Shell, grep,
    Diff-Vorschau, Oberflaeche) nutzen diese eine Funktion."""
    for secret in secrets:
        if secret and len(secret) >= MIN_SECRET_CHARS:
            text = text.replace(secret, "[REDACTED]")
    return KEY_PATTERN.sub("[REDACTED]", zerlegte_schluessel(text))


def scrub_folgezeile(vor, zeile, secrets=()):
    """Maskiert eine einzeln gezeigte Zeile (grep), deren Anfang zu einem Schluessel aus den Vorzeilen gehoeren kann."""
    start = len(vor) + 1
    for a, b in schluessel_bereiche(vor + "\n" + zeile):
        if a < start < b:
            zeile = "[REDACTED]" + zeile[b - start:]
            break
    return scrub_text(zeile, secrets)


class Logger:
    """Schreibt pro Aufgabe eine JSON-Zeile pro Aktion. Schluessel werden vor dem Schreiben entfernt."""

    def __init__(self, log_dir, secrets=()):
        self.secrets = [s for s in secrets if s and len(s) >= MIN_SECRET_CHARS]
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        name = time.strftime("%Y%m%d-%H%M%S") + "-%d-%s.jsonl" % (os.getpid(), uuid.uuid4().hex[:6])
        self.path = Path(log_dir) / name
        self.fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)

    def scrub(self, text):
        return scrub_text(text, self.secrets)

    def clean(self, value):
        """Erst maskieren, dann kuerzen (sonst bleibt bei der Kuerzung ein Schluesselanfang stehen)."""
        if isinstance(value, str):
            if value[:1] in ("{", "["):  # JSON-Text (z. B. Werkzeug-Argumente): Inhalt maskieren, JSON bleibt gueltig
                try:
                    parsed = json.loads(value)
                except ValueError:
                    parsed = None
                if parsed is not None:
                    return json.dumps(self.clean(parsed), ensure_ascii=False)[:MAX_FIELD_CHARS]
            return self.scrub(value)[:MAX_FIELD_CHARS]
        if isinstance(value, dict):
            return {self.scrub(str(k)): self.clean(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [self.clean(v) for v in value]
        return value

    def log(self, event, **fields):
        line = json.dumps({"ts": round(time.time(), 3), "event": event, **self.clean(fields)},
                          ensure_ascii=False, default=str)
        os.write(self.fd, (line + "\n").encode())

    def close(self):
        os.close(self.fd)
