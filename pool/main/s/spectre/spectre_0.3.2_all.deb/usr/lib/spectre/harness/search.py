"""Werkzeuge grep und glob. Nur Standardbibliothek, nur unterhalb von work_dir (gleiche Pfadsperre wie files.py).

Die Suche laeuft in einem eigenen Unterprozess mit Zeit-, CPU- und Speichergrenze: ein haengendes Muster
(regulaere Ausdruecke koennen exponentiell lange rechnen und blockieren den ganzen Prozess) wird nach
GREP_SECONDS hart beendet; bis dahin gefundene Treffer bleiben erhalten.
Symlinks werden ignoriert, .env-Dateien und gesperrte Pfade uebersprungen, Binaerdateien und Dateien > 1 MB ebenfalls.
Jede Ausgabe wird erst von Schluesseln gereinigt und dann gekuerzt."""
import json
import os
import re
import resource
import signal
import subprocess
import sys
import time
from pathlib import Path

from . import files
from .log import scrub_folgezeile, scrub_text
from .tools import Tool, ToolError

MAX_HITS = 50
LINE_CHARS = 200
VOR_ZEILEN, VOR_CHARS = 3, 200  # Vorzeilen je Treffer fuer zerlegte Schluessel (ein Schluessel ist hoechstens 80 Zeichen)
SEND_LINE_CHARS = 20000   # so viel einer Zeile geht vom Unterprozess an den Kern (dort erst maskieren, dann auf LINE_CHARS kuerzen)
MAX_FILE_BYTES = 1024 * 1024
MAX_GLOB = 200
SECONDS = 5
MAX_PATTERN = 300
CHILD_MEMORY = 1024 * 1024 * 1024
PKG_PARENT = str(Path(__file__).resolve().parent.parent)


# ---------------------------------------------------------------- Muster (laeuft im Unterprozess)

def _segment(seg):
    out, i = "", 0
    while i < len(seg):
        c = seg[i]
        if c == "*":
            while i + 1 < len(seg) and seg[i + 1] == "*":
                i += 1
            out += "[^/]*"
        elif c == "?":
            out += "[^/]"
        elif c == "[" and "]" in seg[i + 2:]:
            j = seg.index("]", i + 2)
            body = seg[i + 1:j]
            neg = body.startswith("!")
            body = re.sub(r"[\\^\[]", lambda m: "\\" + m.group(), body[1:] if neg else body)
            out += "[" + ("^" if neg else "") + body + "]"
            i = j
        else:
            out += re.escape(c)
        i += 1
    return out


def glob_regex(pattern):
    """Glob mit *, ?, [abc] und ** (beliebig viele Ordner) als regulaerer Ausdruck."""
    if not isinstance(pattern, str) or not pattern.strip():
        raise ToolError("pattern fehlt oder ist kein Text")
    if len(pattern) > MAX_PATTERN or pattern.count("**") > 3:
        raise ToolError("Muster zu lang oder zu viele **")
    segs = pattern.strip("/").split("/")
    out = ""
    for i, seg in enumerate(segs):
        last = i == len(segs) - 1
        if seg == "**":
            out += ".*" if last else "(?:[^/]+/)*"
        else:
            out += _segment(seg) + ("" if last else "/")
    return re.compile(out + r"\Z", re.S)


def _blocked_name(name):
    n = name.lower()
    return n == ".env" or n.startswith(".env.")


def _walk(root, start, deny):
    """Liefert (relativer Pfad, Teile) jeder normalen Datei unter start; folgt keinen Symlinks."""
    for dirpath, dirnames, filenames in os.walk(start, followlinks=False):
        keep = []
        for d in sorted(dirnames):
            p = os.path.join(dirpath, d)
            if not (_blocked_name(d) or os.path.islink(p) or any(p == x or p.startswith(x + os.sep) for x in deny)):
                keep.append(d)
        dirnames[:] = keep
        for f in sorted(filenames):
            p = os.path.join(dirpath, f)
            if _blocked_name(f) or os.path.islink(p) or any(p == x or p.startswith(x + os.sep) for x in deny):
                yield None, None
                continue
            rel = os.path.relpath(p, root)
            yield rel, rel.split(os.sep)


def _emit(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def child():
    """Einstieg des Unterprozesses: liest eine Anfrage (JSON) von stdin, schreibt Ergebnis-Zeilen nach stdout."""
    resource.setrlimit(resource.RLIMIT_AS, (CHILD_MEMORY, CHILD_MEMORY))
    resource.setrlimit(resource.RLIMIT_CPU, (SECONDS + 3, SECONDS + 3))
    req = json.loads(sys.stdin.read())
    root, start, deny = req["root"], req["start"], set(req["deny"])
    sb = files.Sandbox(root, deny, lambda *a, **k: None)
    skipped = seen = 0
    try:
        gx = glob_regex(req["glob"]) if req.get("glob") else None
        if req["op"] == "glob":
            hits = 0
            for rel, _parts in _walk(root, start, deny):
                if rel is None:
                    continue
                seen += 1
                if gx.match(rel[len(req["prefix"]):].lstrip("/") if req["prefix"] else rel):
                    if hits >= MAX_GLOB:
                        _emit({"done": {"more": True, "seen": seen, "skipped": skipped}})
                        return
                    hits += 1
                    _emit({"path": rel})
            _emit({"done": {"more": False, "seen": seen, "skipped": skipped}})
            return
        flags = re.I if req.get("ignore_case") else 0
        rx = re.compile(req["pattern"] if req["regex"] else re.escape(req["pattern"]), flags)
        if os.path.isfile(start):
            items = [(os.path.relpath(start, root), os.path.relpath(start, root).split(os.sep))]
        else:
            items = _walk(root, start, deny)
        hits = 0
        for rel, parts in items:
            if rel is None:
                skipped += 1
                continue
            if gx and not gx.match(rel if "/" in req["glob"] else os.path.basename(rel)):
                continue
            try:
                fd, size = sb.open(parts, os.O_RDONLY)
            except (files.Blocked, files.FileError, OSError):
                skipped += 1
                continue
            with os.fdopen(fd, "rb") as f:
                if size > MAX_FILE_BYTES or b"\0" in f.read(4096):
                    skipped += 1
                    continue
                f.seek(0)
                seen += 1
                vor = []  # die letzten Zeilen: der Kern prueft damit, ob ein Treffer der Rest eines zerlegten Schluessels ist
                for n, raw in enumerate(f, 1):
                    line = raw.decode("utf-8", "replace").rstrip("\r\n")
                    if rx.search(line):
                        if hits >= MAX_HITS:
                            _emit({"done": {"more": True, "seen": seen, "skipped": skipped}})
                            return
                        hits += 1
                        _emit({"hit": [rel, n, line[:SEND_LINE_CHARS], "\n".join(vor)[-VOR_CHARS:]]})
                    vor = (vor + [line[-VOR_CHARS:]])[-VOR_ZEILEN:]
        _emit({"done": {"more": False, "seen": seen, "skipped": skipped}})
    except re.error as e:
        _emit({"error": "Ungueltiges Muster: %s" % e})
    except ToolError as e:
        _emit({"error": str(e)})


# ---------------------------------------------------------------- Kern-Seite

def _run_child(req, seconds):
    """Startet die Suche, wartet hoechstens `seconds`, beendet sonst die ganze Prozessgruppe. -> (Zeilen, Zeitgrenze erreicht)"""
    p = subprocess.Popen(
        [sys.executable, "-I", "-c", "import sys;sys.path.insert(0,%r);from harness import search;search.child()" % PKG_PARENT],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, start_new_session=True,
        env={"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LANG": "C.UTF-8"}, close_fds=True)
    timed_out = False
    try:
        out, _ = p.communicate(json.dumps(req).encode(), timeout=seconds)
    except subprocess.TimeoutExpired as e:
        timed_out = True
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            out, _ = p.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            out = e.output or b""
        p.wait()
    p.stdout.close() if p.stdout else None
    lines = []
    for raw in (out or b"").decode("utf-8", "replace").splitlines():
        try:
            lines.append(json.loads(raw))
        except ValueError:
            pass  # abgeschnittene letzte Zeile nach dem Abbruch
    return lines, timed_out


def register(registry, work_dir, deny_paths, log, secrets=(), seconds=SECONDS):
    sb = files.Sandbox(work_dir, deny_paths, log)

    def mask(text):
        return scrub_text(text, secrets)

    def start_of(args, want_dir):
        raw = args.get("path")
        if raw in (None, "", "."):
            return sb.root, ""
        parts = sb.resolve(raw)
        real = os.path.join(sb.root, *parts)
        if os.path.islink(real) or not os.path.exists(real):
            raise files.FileError("Pfad nicht gefunden")
        if want_dir and not os.path.isdir(real):
            raise files.FileError("kein Ordner")
        return real, "/".join(parts)

    def ask(op, args, start, prefix, extra):
        req = {"op": op, "root": sb.root, "start": start, "prefix": prefix, "deny": sorted(sb.deny), **extra}
        lines, timed_out = _run_child(req, seconds)
        for item in lines:
            if "error" in item:
                raise ToolError(mask(item["error"]))
        done = next((i["done"] for i in lines if "done" in i), {})
        return lines, done, timed_out

    def grep(args):
        pattern = args.get("pattern")
        if not isinstance(pattern, str) or not pattern:
            raise ToolError("pattern fehlt oder ist kein Text")
        if len(pattern) > MAX_PATTERN:
            raise ToolError("pattern laenger als %d Zeichen" % MAX_PATTERN)
        glob_arg = args.get("glob")
        if glob_arg is not None:
            glob_regex(glob_arg)
        start, prefix = start_of(args, want_dir=False)
        lines, done, timed_out = ask("grep", args, start, prefix, {
            "pattern": pattern, "regex": args.get("regex") is True, "ignore_case": args.get("ignore_case") is True,
            "glob": glob_arg})
        hits = [i["hit"] for i in lines if "hit" in i]
        out = ["%s:%d: %s" % (mask(rel), n, scrub_folgezeile(vor, text, secrets)[:LINE_CHARS]) for rel, n, text, vor in hits]
        notes = []
        if done.get("more"):
            notes.append("nur die ersten %d Treffer, es gibt mehr" % MAX_HITS)
        if timed_out:
            notes.append("nach %d s abgebrochen (Muster zu aufwendig oder zu viele Dateien), Ergebnis unvollstaendig" % seconds)
        if done.get("skipped"):
            notes.append("%d Dateien uebersprungen (binaer, > 1 MB, .env oder gesperrt)" % done["skipped"])
        if not out:
            return "Keine Treffer%s." % (" (" + "; ".join(notes) + ")" if notes else "")
        return "\n".join(out) + ("\n[" + "; ".join(notes) + "]" if notes else "")

    def glob(args):
        gx = args.get("pattern")
        glob_regex(gx)
        start, prefix = start_of(args, want_dir=True)
        lines, done, timed_out = ask("glob", args, start, prefix, {"glob": gx})
        paths = [mask(i["path"]) for i in lines if "path" in i]
        notes = []
        if done.get("more"):
            notes.append("nur die ersten %d Pfade, es gibt mehr" % MAX_GLOB)
        if timed_out:
            notes.append("nach %d s abgebrochen, Ergebnis unvollstaendig" % seconds)
        if not paths:
            return "Keine Dateien gefunden%s." % (" (" + "; ".join(notes) + ")" if notes else "")
        return "\n".join(paths) + ("\n[" + "; ".join(notes) + "]" if notes else "")

    registry.register(Tool(
        "grep", "Search file contents under work/ (text or regex). Max 50 hits as file:line: text; skips binary, >1 MB, .env.",
        {"type": "object", "properties": {
            "pattern": {"type": "string"}, "regex": {"type": "boolean", "description": "pattern is a regular expression (default: plain text)"},
            "path": {"type": "string", "description": "file or folder relative to work/ (default: all of work/)"},
            "glob": {"type": "string", "description": "only files matching this name pattern, e.g. *.py"},
            "ignore_case": {"type": "boolean"}}, "required": ["pattern"]},
        files.guard(log, "grep", grep), max_output_chars=MAX_HITS * (LINE_CHARS + 120) + 400))
    registry.register(Tool(
        "glob", "List files under work/ by name pattern (*, ?, [abc], ** for any folders). Max 200 paths relative to work/.",
        {"type": "object", "properties": {
            "pattern": {"type": "string", "description": "e.g. **/*.py or src/*.txt"},
            "path": {"type": "string", "description": "start folder relative to work/ (default: work/); the pattern is relative to it"}},
         "required": ["pattern"]},
        files.guard(log, "glob", glob), max_output_chars=MAX_GLOB * 150 + 300))
