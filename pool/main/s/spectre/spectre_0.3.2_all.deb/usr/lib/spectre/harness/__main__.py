import argparse
import os
import select
import signal
import sys
from pathlib import Path

from . import __version__
from .api import SetupError, run_task
from .config import BASE, PACKAGED, load_config, set_zdr
from .log import scrub_text
from .shell import sichtbar


def start_ui():
    """`spectre` ohne Aufgabe: Oberflaeche aus dem Paket spectre-code (oder aus ./ui in der Entwicklung) oeffnen."""
    lib = Path(os.environ.get("SPECTRE_CODE_LIB") or ("/usr/lib/spectre-code" if PACKAGED else BASE / "ui"))
    if not (lib / "spectre_code").is_dir():
        sys.exit("Die Oberflaeche ist nicht installiert. Installieren mit: sudo apt install spectre-code\n"
                 "Eine einzelne Aufgabe geht auch so: spectre \"Aufgabe\"")
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        sys.exit("Die Oberflaeche braucht ein Terminal. Fuer Skripte: spectre \"Aufgabe\"")
    sys.path[:0] = [str(lib / "vendor"), str(lib)]
    try:
        from spectre_code.app import main as ui_main
    except ImportError as e:
        sys.exit("Die Oberflaeche konnte nicht geladen werden: %s" % e)
    if ui_main() == "update":
        from .update import run_update
        sys.exit(run_update() if PACKAGED else "Update gibt es nur bei der installierten Version (apt).")


def config_command(args):
    """`spectre config` zeigt den Zustand, `spectre config zdr on|off` schaltet Zero Data Retention (Standard: aus)."""
    if args and (len(args) != 2 or args[0] != "zdr" or args[1] not in ("on", "off")):
        return "Benutzung: spectre config            (Zustand zeigen)\n         spectre config zdr on|off   (nur Anbieter ohne Datenspeicherung)"
    if args:
        set_zdr(args[1] == "on")
    cfg = load_config()
    print("ZDR: %s" % ("an (OpenRouter nutzt nur Endpunkte ohne Datenspeicherung; manche Modelle gehen dann nicht)"
                       if cfg["provider"].get("zdr") is True else "aus"))
    return None


APPROVE_SECONDS = 60


def make_tty_approve(work_dir):
    """Frage im Terminal, nur mit echter Tastatur. Standard ist Nein: Enter, Eingabefehler, Ende der Eingabe, Zeitablauf."""
    def approve(name, args):
        if not (sys.stdin.isatty() and sys.stderr.isatty()):
            return False
        command = args.get("command") if isinstance(args, dict) else None
        sys.stderr.write("\nFreigabe noetig: %s\n" % name)
        if name == "shell" and isinstance(command, str):
            sys.stderr.write("  Befehl: %s\n  Ordner: %s\n" % (sichtbar(scrub_text(command)), work_dir))
        elif isinstance(args, dict) and "_vorschau" in args:
            sys.stderr.write("  Datei: %s\n" % sichtbar(scrub_text(str(args.get("path")))))
            sys.stderr.write("  %s\n" % scrub_text(str(args["_vorschau"])).replace("\n", "\n  "))
        else:
            sys.stderr.write("  Argumente: %s\n" % sichtbar(scrub_text(str(args))[:800]))
        sys.stderr.write("Ausfuehren? [j/N] (ohne Antwort gilt nach %d s Nein): " % APPROVE_SECONDS)
        sys.stderr.flush()
        try:
            ready, _, _ = select.select([sys.stdin], [], [], APPROVE_SECONDS)
            answer = sys.stdin.readline().strip().lower() if ready else ""
        except (OSError, ValueError):
            answer = ""
        sys.stderr.write("\n")
        return answer in ("j", "ja", "y", "yes")
    return approve


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "config":
        sys.exit(config_command(sys.argv[2:]))
    if len(sys.argv) > 1 and sys.argv[1] == "init":  # `spectre init`: Schluessel und Ordner einrichten
        from .init import init
        sys.exit(init())
    if len(sys.argv) == 1:
        start_ui()
        return
    ap = argparse.ArgumentParser(prog="spectre" if PACKAGED else "python3 -m harness",
                                 description="Kleines Coding-Harness. Erste Einrichtung: spectre init")
    ap.add_argument("--version", action="version", version="spectre " + __version__)
    ap.add_argument("task", help="Aufgabe als Text")
    ap.add_argument("--fake", action="store_true", help="Attrappen-Modell statt OpenRouter (kein Schluessel noetig)")
    ap.add_argument("--fake-delay", type=float, default=0.0, help=argparse.SUPPRESS)
    ap.add_argument("--config", help="Pfad zu einer anderen config.json")
    ap.add_argument("--workdir", help="Arbeitsordner (nur darin darf das Modell Dateien lesen und schreiben)")
    args = ap.parse_args()

    def on_signal(signum, frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, on_signal)
    try:
        work_dir = str(Path(args.workdir).expanduser().resolve()) if args.workdir else load_config(args.config)["work_dir"]
        out = run_task(args.task, fake=args.fake, fake_delay=args.fake_delay, config=args.config, workdir=args.workdir,
                       warn=lambda m: print(m, file=sys.stderr),
                       approve=make_tty_approve(work_dir) if sys.stdin.isatty() and sys.stderr.isatty() else None,
                       approve_timeout=APPROVE_SECONDS + 5)
    except SetupError as e:
        sys.exit("Fehler: %s" % e)
    res = out.result
    text = scrub_text(out.text)  # Schluessel (auch zerlegte) nie im Terminal
    print(text if out.ok else "ABBRUCH (%s): %s" % (out.reason, text), file=sys.stdout if out.ok else sys.stderr)
    print("[%d Schritte, %.6f USD (Hauptlauf %.6f, Verdichtung %.6f), %.1f s, Protokoll: %s]" % (
        res.steps, res.cost_usd, res.cost_main_usd, res.cost_compaction_usd, res.seconds, out.log_path),
          file=sys.stderr)
    sys.exit(0 if out.ok else 130 if out.reason == "interrupted" else 2)


if __name__ == "__main__":
    main()
