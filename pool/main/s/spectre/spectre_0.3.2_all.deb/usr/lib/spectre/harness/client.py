import json
import socket
import time
import urllib.error
import urllib.request


class ModelError(Exception):
    pass


class ModelTimeout(ModelError):
    pass


class OpenRouterClient:
    """OpenAI-kompatibler Chat-Client (nur urllib). Der Schluessel steht nur im Header."""

    def __init__(self, api_key, base_url, model, max_reply_tokens, session_id=None, cache_control_models=(), zdr=False):
        self.session_id = session_id  # gleiche ID ueber alle Aufrufe einer Sitzung (Sticky Routing, max. 256 Zeichen)
        self.cache_control = any(model.startswith(p) for p in cache_control_models)
        self.zdr = zdr  # True: OpenRouter darf nur Endpunkte ohne Datenspeicherung nutzen (provider.zdr); kein stilles Zurueckfallen
        self.api_key = api_key
        self.url = base_url.rstrip("/") + "/chat/completions"
        self.model = model
        self.max_reply_tokens = max_reply_tokens

    def chat(self, messages, tools, timeout):
        body = {"model": self.model, "messages": messages, "max_tokens": self.max_reply_tokens,
                "usage": {"include": True}}
        if self.session_id:
            body["session_id"] = self.session_id[:256]
        if self.cache_control:  # Anthropic: automatisches Caching (cache_control oben in der Anfrage)
            body["cache_control"] = {"type": "ephemeral"}
        if self.zdr:
            body["provider"] = {"zdr": True}
        if tools:
            body["tools"] = tools
        req = urllib.request.Request(
            self.url, data=json.dumps(body).encode(), method="POST",
            headers={"Authorization": "Bearer " + self.api_key, "Content-Type": "application/json",
                     "X-Title": "harness"})
        try:
            with urllib.request.urlopen(req, timeout=max(timeout, 1)) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            detail = e.read()[:300].decode("utf-8", "replace")
            if self.zdr and e.code in (400, 403, 404):  # ZDR verlangt, aber kein passender Endpunkt: klar sagen, nicht ohne ZDR wiederholen
                raise ModelError("ZDR ist an, aber OpenRouter hat fuer dieses Modell keinen passenden Endpunkt ohne "
                                 "Datenspeicherung (HTTP %d: %s). Es wird nicht ohne ZDR wiederholt. Waehle ein anderes "
                                 "Modell oder schalte ZDR aus: spectre config zdr off" % (e.code, detail))
            raise ModelError("HTTP %d: %s" % (e.code, detail))
        except (socket.timeout, TimeoutError):
            raise ModelTimeout("Zeitueberschreitung beim Modellaufruf")
        except urllib.error.URLError as e:
            if isinstance(e.reason, (socket.timeout, TimeoutError)):
                raise ModelTimeout("Zeitueberschreitung beim Modellaufruf")
            raise ModelError("Verbindungsfehler: %s" % e.reason)
        except ValueError:
            raise ModelError("Antwort war kein gueltiges JSON")


class FakeClient:
    """Attrappe fuer Tests: spielt eine Liste vorbereiteter Antworten ab (die letzte wiederholt sich)."""

    def __init__(self, script=None, delay=0.0):
        self.script = script or [{"message": {"role": "assistant", "content": "[Attrappe] fertig."}}]
        self.delay = delay
        self.calls = 0
        self.last_messages = self.last_tools = None
        self.sent = []  # JSON jeder Anfrage (Nachrichten, Werkzeuge), fuer Tests

    def chat(self, messages, tools, timeout):
        self.last_messages, self.last_tools = messages, tools
        self.sent.append((json.dumps(messages, ensure_ascii=False), json.dumps(tools)))
        time.sleep(self.delay)
        reply = self.script[min(self.calls, len(self.script) - 1)]
        self.calls += 1
        out = {"choices": [{"message": reply["message"]}] if reply.get("message") else []}
        if "usage" in reply:
            out["usage"] = reply["usage"]
        return out
