import json
import os
from pathlib import Path

PACKAGED = (Path(__file__).resolve().parent / "_packaged").exists()  # Datei kommt nur ins .deb
BASE = Path(os.environ.get("HARNESS_HOME", Path(__file__).resolve().parent.parent))
if PACKAGED and "HARNESS_HOME" not in os.environ:
    _home = Path(os.environ.get("HOME") or Path.home())
    CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME") or _home / ".config") / "spectre"
    DATA_DIR = Path(os.environ.get("XDG_DATA_HOME") or _home / ".local" / "share") / "spectre"
    WORK_DIR = _home / "spectre-work"
else:  # Entwicklung (/srv/harness): alles unter BASE wie bisher
    CONFIG_DIR, DATA_DIR, WORK_DIR = BASE, BASE, BASE / "work"

DEFAULTS = {
    "model": "openai/gpt-4o-mini",
    "base_url": "https://openrouter.ai/api/v1",
    "max_reply_tokens": 1024,
    "max_tool_output_chars": 4000,
    "price_in_per_mtok": 0.15,
    "price_out_per_mtok": 0.60,
    "limits": {"max_steps": 15, "max_seconds": 120, "max_cost_usd": 0.50, "max_format_errors": 3},
    "context": {
        "placeholder_after_steps": 4,      # Werkzeugergebnisse aelter als N Schritte werden gekuerzt (0 = aus)
        "compaction": True,                # Verdichtung an/aus
        "compact_after_messages": 12,      # mehr Verlaufsnachrichten als das loest die Verdichtung aus ...
        "compact_at_fraction": 0.5,        # ... oder dieser Anteil des Kontextfensters
        "keep_raw_messages": 6,            # so viele letzte Nachrichten bleiben roh
        "summary_max_chars": 1500,         # Faktenliste
        "open_points_max_chars": 500,      # Offene Punkte im Verlauf (die Notiz darf 2000 haben)
        "compact_max_tokens": 60000,       # absoluter Deckel: Verdichtung spaetestens hier, egal wie gross das Fenster ist (0 = aus)
        "windows": {                       # Kontextfenster in Token, pro Modellname, sonst "default"
            "default": 128000,
            "anthropic/claude-haiku-5.5": 1000000,
            "moonshotai/kimi-k2": 131072,
            "openai/gpt-4o-mini": 128000,
            "openai/gpt-5-mini": 400000,
        },
    },
    "summarizer": {"model": None, "max_reply_tokens": 700, "timeout_seconds": 60},  # model None = Hauptmodell
    "provider": {"zdr": False},            # True: nur Anbieter ohne Datenspeicherung (kann Modellauswahl einschraenken)
    "cache_control_models": ["anthropic/"],  # nur hier schickt der Client cache_control (laut OpenRouter-Doku noetig)
    "deny_paths": [],                      # zusaetzlich fuer die Dateiwerkzeuge gesperrte Pfade
    "log_dir": str(DATA_DIR / "logs"),
    "work_dir": str(WORK_DIR),
    "memory_dir": str(DATA_DIR / "memory"),
}


def merge(base, user):
    """Verschachtelte Abschnitte (limits, context, ...) werden eingemischt, nicht ersetzt."""
    for k, v in user.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            merge(base[k], v)
        else:
            base[k] = v


def load_config(path=None):
    cfg = json.loads(json.dumps(DEFAULTS))
    path = Path(path) if path else CONFIG_DIR / "config.json"
    if path.exists():
        try:
            user = json.loads(path.read_text())
        except ValueError as e:
            raise SystemExit("Konfiguration %s ist kein gueltiges JSON: %s" % (path, e))
        merge(cfg, user)
    elif path != CONFIG_DIR / "config.json":
        raise SystemExit("Konfiguration nicht gefunden: %s" % path)
    return cfg


def load_api_key():
    """Schluessel nur aus Umgebungsvariable oder aus CONFIG_DIR/.env. Gibt None zurueck, wenn keiner da ist."""
    key = os.environ.get("OPENROUTER_API_KEY")
    if key:
        return key.strip()
    env_file = CONFIG_DIR / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            name, _, value = line.partition("=")
            if name.strip() == "OPENROUTER_API_KEY" and value.strip():
                return value.strip().strip('"').strip("'")
    return None


def set_zdr(value):
    """Schreibt provider.zdr in die Benutzer-Konfiguration (nur dieser Eintrag, Rest bleibt); Datei wird ersetzt, nicht halb geschrieben."""
    path = CONFIG_DIR / "config.json"
    user = {}
    if path.exists():
        try:
            user = json.loads(path.read_text())
        except ValueError as e:
            raise SystemExit("Konfiguration %s ist kein gueltiges JSON: %s" % (path, e))
        if not isinstance(user, dict):
            raise SystemExit("Konfiguration %s hat nicht die erwartete Form" % path)
    if not isinstance(user.get("provider"), dict):
        user["provider"] = {}
    user["provider"]["zdr"] = bool(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(user, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)
    return path
