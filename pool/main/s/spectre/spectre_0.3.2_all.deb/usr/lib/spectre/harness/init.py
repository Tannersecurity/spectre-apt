"""`spectre init`: legt Ordner an, fragt den Schluessel mit verdecktem Eingabefeld und speichert ihn (Rechte 600).
Der Schluessel wird nie ausgegeben und nie von woanders kopiert."""
import getpass
import json
import os
import secrets
import sys
from pathlib import Path

from .config import CONFIG_DIR, DATA_DIR, WORK_DIR

START_CONFIG = {  # nur was vom Standard abweicht
    "model": "anthropic/claude-haiku-5.5",
    "price_in_per_mtok": 0.10,
    "price_out_per_mtok": 0.50,
}


def write_secret(path, text):
    """Schreibt eine Datei, die von Anfang an nur dem Benutzer gehoert (Rechte 600, kein offenes Fenster)."""
    tmp = Path("%s.%s.tmp" % (path, secrets.token_hex(6)))  # neuer Name, O_EXCL + O_NOFOLLOW: folgt keinem Symlink
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def make_private_dir(path):
    """Legt den Ordner mit Rechten 700 an. Ein schon vorhandener Ordner behaelt seine Rechte."""
    new = not path.exists()
    path.mkdir(parents=True, exist_ok=True)
    if new:
        os.chmod(path, 0o700)


def init(ask_key=getpass.getpass, ask=input, out=sys.stdout):
    try:
        return _init(ask_key, ask, out)
    except (EOFError, KeyboardInterrupt):
        print("\nEingabe abgebrochen, nichts gespeichert.", file=sys.stderr)
        return 1
    except OSError as e:
        print("Fehler: %s (%s). Nichts gespeichert." % (e.strerror or e, e.filename or "?"), file=sys.stderr)
        return 1


def _init(ask_key, ask, out):
    for d in (CONFIG_DIR, DATA_DIR):
        make_private_dir(d)
        os.chmod(d, 0o700)
    make_private_dir(WORK_DIR)
    cfg = CONFIG_DIR / "config.json"
    if not cfg.is_symlink() and not cfg.exists():
        fd = os.open(cfg, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(json.dumps(START_CONFIG, indent=2) + "\n")
    env = CONFIG_DIR / ".env"
    if env.exists() and ask("Es gibt schon einen Schluessel (%s). Ersetzen? [j/N] " % env).strip().lower() not in ("j", "ja"):
        print("Schluessel bleibt unveraendert.", file=out)
    else:
        key = ask_key("OpenRouter-Schluessel (Eingabe bleibt unsichtbar): ").strip()
        if not key or any(c.isspace() for c in key):
            print("Kein gueltiger Schluessel eingegeben, nichts gespeichert.", file=sys.stderr)
            return 1
        write_secret(env, "OPENROUTER_API_KEY=%s\n" % key)
        print("Schluessel gespeichert in %s (nur du kannst ihn lesen)." % env, file=out)
    print("Konfiguration: %s\nDaten und Protokolle: %s\nArbeitsordner: %s\nStart: spectre \"Aufgabe\"" % (
        cfg, DATA_DIR, WORK_DIR), file=out)
    return 0
