import argparse
import os
import signal
import sys
from pathlib import Path

from . import __version__
from .api import SetupError, run_task
from .config import BASE, PACKAGED


def start_ui():
    """`spectre` ohne Aufgabe: Oberflaeche aus dem Paket spectre-code (oder aus ./ui in der Entwicklung) oeffnen."""
    lib = Path(os.environ.get("SPECTRE_CODE_LIB") or ("/usr/lib/spectre-code" if PACKAGED else BASE / "ui"))
    if not (lib / "spectre_code").is_dir():
        sys.exit("Die Oberflaeche ist nicht installiert. Installieren mit: sudo apt install spectre-code\n"
                 "Eine einzelne Aufgabe geht auch so: spectre \"Aufgabe\"")
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        sys.exit("Die Oberflaeche braucht ein Terminal. Fuer Skripte: spectre \"Aufgabe\"")
    sys.path[:0] = [str(lib / "vendor"), str(lib)]
    try:
        from spectre_code.app import main as ui_main
    except ImportError as e:
        sys.exit("Die Oberflaeche konnte nicht geladen werden: %s" % e)
    if ui_main() == "update":
        from .update import run_update
        sys.exit(run_update() if PACKAGED else "Update gibt es nur bei der installierten Version (apt).")


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "init":  # `spectre init`: Schluessel und Ordner einrichten
        from .init import init
        sys.exit(init())
    if len(sys.argv) == 1:
        start_ui()
        return
    ap = argparse.ArgumentParser(prog="spectre" if PACKAGED else "python3 -m harness",
                                 description="Kleines Coding-Harness. Erste Einrichtung: spectre init")
    ap.add_argument("--version", action="version", version="spectre " + __version__)
    ap.add_argument("task", help="Aufgabe als Text")
    ap.add_argument("--fake", action="store_true", help="Attrappen-Modell statt OpenRouter (kein Schluessel noetig)")
    ap.add_argument("--fake-delay", type=float, default=0.0, help=argparse.SUPPRESS)
    ap.add_argument("--config", help="Pfad zu einer anderen config.json")
    ap.add_argument("--workdir", help="Arbeitsordner (nur darin darf das Modell Dateien lesen und schreiben)")
    args = ap.parse_args()

    def on_signal(signum, frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, on_signal)
    try:
        out = run_task(args.task, fake=args.fake, fake_delay=args.fake_delay, config=args.config, workdir=args.workdir,
                       warn=lambda m: print(m, file=sys.stderr))
    except SetupError as e:
        sys.exit("Fehler: %s" % e)
    res = out.result
    print(out.text if out.ok else "ABBRUCH (%s): %s" % (out.reason, out.text), file=sys.stdout if out.ok else sys.stderr)
    print("[%d Schritte, %.6f USD (Hauptlauf %.6f, Verdichtung %.6f), %.1f s, Protokoll: %s]" % (
        res.steps, res.cost_usd, res.cost_main_usd, res.cost_compaction_usd, res.seconds, out.log_path),
          file=sys.stderr)
    sys.exit(0 if out.ok else 130 if out.reason == "interrupted" else 2)


if __name__ == "__main__":
    main()
