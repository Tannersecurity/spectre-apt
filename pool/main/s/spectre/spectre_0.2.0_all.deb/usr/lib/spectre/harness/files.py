"""Dateiwerkzeuge mit Pfadsperre. Alles nur unterhalb von work_dir; die Sperre steht im Code, nicht im Prompt."""
import errno
import os
import stat

from .tools import Tool, ToolError

MAX_PATH_CHARS = 1024
READ_LINES = 200
READ_BYTES = 8192
WRITE_BYTES = 64 * 1024
MAX_READ_FILE = 5 * 1024 * 1024
DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW


class Blocked(Exception):
    """Verstoss gegen die Pfadsperre: Meldung ans Modell und Protokolleintrag."""


class FileError(Exception):
    """Normaler Fehler (nicht gefunden, zu gross, ...): kurze Meldung ans Modell."""


class Sandbox:
    def __init__(self, work_dir, deny_paths, log):
        os.makedirs(work_dir, exist_ok=True)
        self.root = os.path.realpath(work_dir)
        self.deny = {os.path.normpath(str(p)) for p in deny_paths} | {os.path.realpath(str(p)) for p in deny_paths}
        self.log = log

    def resolve(self, raw):
        """Prueft den Pfad und gibt die Teile relativ zu work zurueck."""
        if not isinstance(raw, str) or not raw.strip():
            raise ToolError("path fehlt oder ist kein Text")
        if "\0" in raw:
            raise Blocked("Nullbyte im Pfad")
        if len(raw) > MAX_PATH_CHARS:
            raise Blocked("Pfad zu lang")
        if "~" in raw:
            raise Blocked("~ im Pfad")
        if ".." in raw.split("/"):
            raise Blocked("'..' im Pfad")
        lexical = os.path.normpath(raw if raw.startswith("/") else os.path.join(self.root, raw))
        real = os.path.realpath(lexical)
        for path in (lexical, real):
            for part in path.split(os.sep):
                if part.lower() == ".env" or part.lower().startswith(".env."):
                    raise Blocked(".env-Datei")
            if any(path == d or path.startswith(d + os.sep) for d in self.deny):
                raise Blocked("gesperrter Pfad")
        if real != self.root and not real.startswith(self.root + os.sep):
            raise Blocked("ausserhalb von work" + (" (Symlink?)" if real != lexical else ""))
        if real == self.root:
            raise FileError("das ist der work-Ordner")
        return os.path.relpath(real, self.root).split(os.sep)

    def open(self, parts, flags, create=False):
        """Oeffnet Schritt fuer Schritt ab work, ohne Symlinks zu folgen (gegen Tausch zwischen Pruefen und Oeffnen)."""
        dfd = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            for part in parts[:-1]:
                try:
                    nfd = os.open(part, DIR_FLAGS, dir_fd=dfd)
                except FileNotFoundError:
                    if not create:
                        raise
                    os.mkdir(part, 0o700, dir_fd=dfd)
                    nfd = os.open(part, DIR_FLAGS, dir_fd=dfd)
                except OSError as e:
                    if e.errno in (errno.ELOOP, errno.ENOTDIR):
                        if stat.S_ISLNK(os.stat(part, dir_fd=dfd, follow_symlinks=False).st_mode):
                            raise Blocked("Symlink im Pfad")
                        raise FileError("%s ist kein Ordner" % part)
                    raise
                os.close(dfd)
                dfd = nfd
            try:
                fd = os.open(parts[-1], flags | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600, dir_fd=dfd)
            except OSError as e:
                if e.errno == errno.ELOOP:
                    raise Blocked("Symlink")
                raise
        finally:
            os.close(dfd)
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
            os.close(fd)
            raise FileError("keine normale Einzeldatei")
        return fd, st.st_size






def _int(args, name, default, minimum):
    v = args.get(name, default)
    if isinstance(v, bool) or not isinstance(v, int) or v < minimum:
        raise ToolError("%s muss eine ganze Zahl >= %d sein" % (name, minimum))
    return v


def _text(args, name):
    v = args.get(name)
    if not isinstance(v, str):
        raise ToolError("%s fehlt oder ist kein Text" % name)
    return v


def _decode(data, partial=False):
    for cut in range(4 if partial else 1):  # bei Kuerzung mitten im Zeichen bis zu 3 Bytes zurueck
        try:
            return data[:len(data) - cut].decode("utf-8")
        except UnicodeDecodeError:
            pass
    raise FileError("Binaerdatei oder kein UTF-8, abgelehnt")


def _write_all(fd, data):
    off = 0
    while off < len(data):
        off += os.pwrite(fd, data[off:], off)


def register(registry, work_dir, deny_paths, log):
    sb = Sandbox(work_dir, deny_paths, log)

    def guarded(tool_name, fn):
        def run(args):
            try:
                return fn(args)
            except Blocked as e:
                log("blocked", tool=tool_name, path=str(args.get("path"))[:300], reason=str(e))
                return "Gesperrt: %s" % e
            except FileError as e:
                return "Fehler: %s" % e
            except OSError as e:
                return "Fehler: %s" % (e.strerror or e)
        return run

    def read_file(args):
        parts = sb.resolve(args.get("path"))
        start = _int(args, "start_line", 1, 1)
        want = min(_int(args, "max_lines", READ_LINES, 1), READ_LINES)
        fd, size = sb.open(parts, os.O_RDONLY)
        with os.fdopen(fd, "rb") as f:
            if size > MAX_READ_FILE:
                raise FileError("Datei groesser als 5 MB")
            if b"\0" in f.read(4096):
                raise FileError("Binaerdatei, abgelehnt")
            f.seek(0)
            lineno, out, used, nxt, cut = 0, [], 0, None, None
            for line in f:
                lineno += 1
                if lineno < start:
                    continue
                if len(out) >= want:
                    nxt = lineno
                    break
                if used + len(line) > READ_BYTES:
                    if out:
                        nxt = lineno
                    else:  # eine einzelne Zeile ist laenger als das Limit
                        out, cut, nxt = [line[:READ_BYTES]], lineno, lineno + 1
                    break
                out.append(line)
                used += len(line)
        if not out:
            return "(leer)" if lineno == 0 else "start_line hinter dem Dateiende (%d Zeilen)" % lineno
        raw = b"".join(out)
        if b"\0" in raw:
            raise FileError("Binaerdatei, abgelehnt")
        text = _decode(raw, partial=cut is not None)
        if nxt is None:
            return text
        note = "Zeile %d war zu lang, gekuerzt. " % cut if cut else ""
        return text + ("" if text.endswith("\n") else "\n") + "[%sabgeschnitten, lies mit start_line=%d weiter]" % (note, nxt)

    def write_file(args):
        text = _text(args, "content")
        data = text.encode("utf-8")
        if len(data) > WRITE_BYTES:
            raise FileError("content groesser als 64 KB")
        parts = sb.resolve(args.get("path"))
        fd, _ = sb.open(parts, os.O_WRONLY | os.O_CREAT, create=True)
        try:
            os.ftruncate(fd, 0)
            _write_all(fd, data)
        finally:
            os.close(fd)
        return "geschrieben: %s (%d Bytes)" % (args["path"], len(data))

    def edit_file(args):
        old, new = _text(args, "old"), _text(args, "new")
        if not old:
            raise ToolError("old darf nicht leer sein")
        parts = sb.resolve(args.get("path"))
        fd, size = sb.open(parts, os.O_RDWR)
        try:
            if size > WRITE_BYTES:
                raise FileError("Datei groesser als 64 KB, edit nicht moeglich")
            text = _decode(os.pread(fd, size, 0))
            n = text.count(old)
            if n == 0:
                raise FileError("old nicht gefunden")
            if n > 1:
                raise FileError("old kommt %dx vor, nimm mehr Kontext" % n)
            data = text.replace(old, new, 1).encode("utf-8")
            if len(data) > WRITE_BYTES:
                raise FileError("Ergebnis groesser als 64 KB")
            os.ftruncate(fd, 0)
            _write_all(fd, data)
        finally:
            os.close(fd)
        return "geaendert: %s" % args["path"]

    path = {"type": "string", "description": "relative to work/"}
    registry.register(Tool(
        "read_file", "Read a text file under work/ (max 200 lines / 8 KB per call).",
        {"type": "object", "properties": {"path": path, "start_line": {"type": "integer"}, "max_lines": {"type": "integer"}},
         "required": ["path"]},
        guarded("read_file", read_file), max_output_chars=READ_BYTES + 300))
    registry.register(Tool(
        "write_file", "Create or replace a text file under work/ (max 64 KB).",
        {"type": "object", "properties": {"path": path, "content": {"type": "string"}}, "required": ["path", "content"]},
        guarded("write_file", write_file)))
    registry.register(Tool(
        "edit_file", "Replace one text passage in a file under work/; old must occur exactly once.",
        {"type": "object", "properties": {"path": path, "old": {"type": "string"}, "new": {"type": "string"}},
         "required": ["path", "old", "new"]},
        guarded("edit_file", edit_file)))
