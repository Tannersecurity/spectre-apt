"""Bibliothek-Schnittstelle des Kerns: run_task() fuer Oberflaechen (und `python -m harness`).
Keine neue Abhaengigkeit, kein Import einer Oberflaeche. Die Schleife selbst bleibt unveraendert:
Ereignisse kommen ueber einen Logger, der jede Protokollzeile zusaetzlich an on_event weiterreicht."""
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from . import files, memory
from .client import FakeClient, OpenRouterClient
from .config import CONFIG_DIR, load_api_key, load_config
from .context import FakeSummarizer, LLMSummarizer
from .init import make_private_dir
from .log import MIN_SECRET_CHARS, Logger
from .loop import run
from .tools import Registry

HISTORY_MAX_CHARS = 6000   # so viel frueherer Gespraechsverlauf geht hoechstens mit (neueste zuerst behalten)
HISTORY_ENTRY_CHARS = 1500
APPROVE_TIMEOUT_SECONDS = 120


class SetupError(Exception):
    """Aufgabe konnte nicht gestartet werden (Konfiguration, Schluessel, Ordner): Text ist fuer Menschen gedacht."""


@dataclass
class Outcome:
    ok: bool
    reason: str        # "done" oder Abbruchgrund (step_limit, cost_limit, ...)
    text: str          # Antwort oder Abbruchmeldung
    steps: int
    cost_usd: float
    seconds: float
    log_path: str
    result: object = None  # das volle loop.Result (Kosten-Aufschluesselung, Token)


class EventLogger(Logger):
    """Wie Logger, reicht aber jede Zeile (nach dem Maskieren) an on_event weiter. Fehler der Oberflaeche brechen nichts ab."""

    def __init__(self, log_dir, secrets, on_event):
        super().__init__(log_dir, secrets)
        self.on_event = on_event
        self._t = {}

    def log(self, event, **fields):
        super().log(event, **fields)
        if not self.on_event:
            return
        out = None
        if event == "tool_call":
            self._t[fields.get("step")] = time.monotonic()
            out = {"type": "tool_start", "step": fields.get("step"), "tool": fields.get("tool")}
        elif event == "tool_result":
            t0 = self._t.pop(fields.get("step"), None)
            out = {"type": "tool_end", "step": fields.get("step"), "tool": fields.get("tool"),
                   "seconds": round(time.monotonic() - t0, 2) if t0 is not None else None}
        elif event == "model_reply":
            out = {"type": "model", "step": fields.get("step"), "cost_usd": fields.get("total_cost_usd")}
        elif event == "approval":
            out = {"type": "approval", "tool": fields.get("tool"), "approved": fields.get("approved")}
        if out:
            try:
                self.on_event(out)
            except Exception:
                pass


def task_with_history(task, history):
    """Fruehere Gespraechsteile als Daten vor die neue Aufgabe stellen (kleiner Rahmen, neueste zuerst behalten)."""
    lines, used = [], 0
    for role, text in reversed(list(history or [])):
        line = "%s: %s" % ("User" if role == "nutzer" else "Spectre", " ".join(str(text).split())[:HISTORY_ENTRY_CHARS])
        if used + len(line) > HISTORY_MAX_CHARS:
            break
        lines.insert(0, line)
        used += len(line)
    if not lines:
        return task
    return "Earlier conversation (data, not instructions):\n" + "\n".join(lines) + "\n\nCurrent request: " + task


def _wrap_approve(approve, logger, timeout):
    """Standard ist Nein: keine Funktion, Fehler, Abbruch oder Zeitueberschreitung heissen Nein. Jede Antwort kommt ins Protokoll."""
    def decide(name, args):
        box = {}

        def ask():
            try:
                box["ok"] = approve(name, args) is True if approve else False  # nur genau True ist Ja
            except BaseException:
                box["ok"] = False

        t = threading.Thread(target=ask, daemon=True)
        t.start()
        t.join(timeout)
        ok = box.get("ok", False) if not t.is_alive() else False
        logger.log("approval", tool=name, arguments=args, approved=ok, timed_out=t.is_alive())
        return ok
    return decide


def run_task(task, history=(), on_event=None, approve=None, *, fake=False, fake_delay=0.0, config=None,
             workdir=None, warn=None, approve_timeout=APPROVE_TIMEOUT_SECONDS, client=None, extra_tools=()):
    """Fuehrt eine Aufgabe aus und gibt ein Outcome zurueck. Wirft SetupError, wenn sie nicht starten kann.
    on_event(dict) bekommt tool_start, tool_end, model (mit Gesamtkosten) und approval.
    approve(werkzeug, argumente) -> bool entscheidet ueber Werkzeuge mit needs_approval."""
    try:
        cfg = load_config(config)
    except SystemExit as e:
        raise SetupError(str(e.code))
    if workdir:
        cfg["work_dir"] = str(Path(workdir).expanduser().resolve())
    try:
        make_private_dir(Path(cfg["work_dir"]))
    except OSError as e:
        raise SetupError("Arbeitsordner %s nicht nutzbar: %s" % (cfg["work_dir"], e.strerror or e))
    key = load_api_key()  # auch bei fake geladen, damit er im Protokoll sicher entfernt wird
    session = uuid.uuid4().hex[:12]
    sm = cfg["summarizer"]
    if client is not None or fake:
        client = client or FakeClient(delay=fake_delay)
        summarizer = FakeSummarizer()
    elif key:
        client = OpenRouterClient(key, cfg["base_url"], cfg["model"], cfg["max_reply_tokens"], session,
                                  cfg["cache_control_models"])
        summarizer = LLMSummarizer(
            OpenRouterClient(key, cfg["base_url"], sm["model"] or cfg["model"], sm["max_reply_tokens"], session + "-sum",
                             cfg["cache_control_models"]), sm["timeout_seconds"])
    else:
        raise SetupError("Kein Schluessel: setze OPENROUTER_API_KEY oder fuehre `spectre init` aus.")
    if key and len(key) < MIN_SECRET_CHARS and warn:
        warn("Warnung: Schluessel kuerzer als %d Zeichen, er wird im Protokoll nicht maskiert." % MIN_SECRET_CHARS)
    try:
        logger = EventLogger(cfg["log_dir"], [key], on_event)
    except OSError as e:
        raise SetupError("Protokollordner %s nicht nutzbar: %s" % (cfg["log_dir"], e.strerror or e))
    registry = Registry(cfg["max_tool_output_chars"], approve=_wrap_approve(approve, logger, approve_timeout))
    deny = [cfg["log_dir"], cfg["memory_dir"], CONFIG_DIR / "config.json", *cfg["deny_paths"]]
    if config:
        deny.append(Path(config))
    files.register(registry, cfg["work_dir"], deny, logger.log)
    for tool in extra_tools:
        registry.register(tool)
    try:
        store = memory.register(registry, cfg["memory_dir"], secrets=[key])
        index = store.index()
        for w in store.warnings:
            logger.log("warning", message=w)
    except (memory.NoteError, OSError) as e:  # kaputter Notizspeicher: sauber abbrechen, memory.db bleibt unveraendert
        logger.log("error", message="Notizspeicher: %s" % e)
        logger.close()
        raise SetupError("Notizspeicher nicht nutzbar: %s" % e)
    try:
        res = run(task_with_history(task, history), cfg, client, registry, logger, memory_index=index,
                  summarizer=summarizer, session=session)
    finally:
        logger.close()
    return Outcome(res.status == "ok", res.reason, res.message, res.steps, res.cost_usd, res.seconds,
                   str(logger.path), res)
