import json
import os
import re
import time
import uuid
from pathlib import Path

# Jedes "sk-" (nicht mitten in einem Wort wie "task-" oder "disk-") plus mindestens 4 Nicht-Leerzeichen.
KEY_PATTERN = re.compile(r"(?<![A-Za-z0-9])sk-\S{4,}")
MAX_FIELD_CHARS = 2000
MIN_SECRET_CHARS = 8  # kuerzere Laufzeit-Schluessel wuerden jedes Vorkommen im Text ersetzen


class Logger:
    """Schreibt pro Aufgabe eine JSON-Zeile pro Aktion. Schluessel werden vor dem Schreiben entfernt."""

    def __init__(self, log_dir, secrets=()):
        self.secrets = [s for s in secrets if s and len(s) >= MIN_SECRET_CHARS]
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        name = time.strftime("%Y%m%d-%H%M%S") + "-%d-%s.jsonl" % (os.getpid(), uuid.uuid4().hex[:6])
        self.path = Path(log_dir) / name
        self.fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)

    def scrub(self, text):
        for secret in self.secrets:
            text = text.replace(secret, "[REDACTED]")
        return KEY_PATTERN.sub("[REDACTED]", text)

    def clean(self, value):
        """Erst maskieren, dann kuerzen (sonst bleibt bei der Kuerzung ein Schluesselanfang stehen)."""
        if isinstance(value, str):
            if value[:1] in ("{", "["):  # JSON-Text (z. B. Werkzeug-Argumente): Inhalt maskieren, JSON bleibt gueltig
                try:
                    parsed = json.loads(value)
                except ValueError:
                    parsed = None
                if parsed is not None:
                    return json.dumps(self.clean(parsed), ensure_ascii=False)[:MAX_FIELD_CHARS]
            return self.scrub(value)[:MAX_FIELD_CHARS]
        if isinstance(value, dict):
            return {self.scrub(str(k)): self.clean(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [self.clean(v) for v in value]
        return value

    def log(self, event, **fields):
        line = json.dumps({"ts": round(time.time(), 3), "event": event, **self.clean(fields)},
                          ensure_ascii=False, default=str)
        os.write(self.fd, (line + "\n").encode())

    def close(self):
        os.close(self.fd)
